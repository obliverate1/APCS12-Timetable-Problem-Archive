"""
School Timetabling Problem — Milestone 2
=========================================
Builds a master timetable (course → semester, block, room) with:
- correct number of sections,
- room assignments respecting course type,
- blocking rules (simultaneous courses forced together),
- sequencing rules (prerequisite → later course semester order),
- capacity and minimum‑enrolment constraints,
- then assigns students, respecting all hard constraints.
"""

# The build_master_timetable in this code does not use CP-SAT

import csv
import os
import random
from collections import defaultdict
from ortools.sat.python import cp_model
from masterTimeTableMaker import check_room_capacities, generate_timetable
from time import perf_counter_ns

# ========================== CONSTANTS ==========================
BLOCKS = ['A', 'B', 'C', 'D']
SEMESTERS = [1, 2]
DATA_DIR = 'data'

# Room ranges (from roomsClean.csv)
ROOM_MIN = 500
ROOM_MAX = 548

# Capacity defaults
DEFAULT_MAX_CAPACITY = 30
LAB_MAX_CAPACITY = 24

# Courses that are considered "labs / specialty" -> capacity 24
LAB_COURSE_PREFIXES = (
    'MATPH', 'MCH', 'MPH', 'MEVSC',      # science
    'MWWK',                              # woodwork
    'MTAUT', 'MTEAD',                    # automotive
    'MTROB',                             # robotics
    'MMACS', 'MCMPR',                    # computer science
    'MTDRF'                              # drafting
)

# ========================== LOAD DATA ==========================
def load_courses():
    """Return dict {course_code: {'sections': int, 'type': str}}."""
    courses = {}
    with open("data/sections.csv") as f:
        for row in csv.reader(f):
            if not row:
                continue
            code = row[0].strip()
            num_sec = int(row[1].strip())
            sched = row[2].strip().upper() if len(row) > 2 and row[2].strip() else 'ED'
            # Courses with codes starting with Y, X, or PBB are Out‑of‑Timetable
            if code.startswith(('Y', 'X', 'PBB')):
                sched = 'OO'
            courses[code] = {'sections': num_sec, 'type': sched}
    return courses

def load_students():
    """Return list of student dicts with id, grade, requests."""
    students = []
    current = None
    with open("data/old/cleanedstudentrequests.csv", encoding='utf-8-sig') as f:
        for row in csv.reader(f):
            if not row:
                continue
            col0 = row[0].strip()
            if col0 == 'ID':
                if current is not None:
                    students.append(current)
                student_id = int(row[1].strip())
                grade = int(row[3].strip()) if len(row) > 3 and row[3].strip().isdigit() else 0
                current = {'id': student_id, 'grade': grade, 'requests': []}
            elif col0 == 'Course' or not col0:
                continue
            elif current is not None:
                current['requests'].append(col0)
    if current is not None:
        students.append(current)
    return students

def load_sequencing():
    """Return list of (prerequisite, later_course) pairs."""
    pairs = []
    path = "data/sequencing.csv"
    if not os.path.exists(path):
        return pairs
    with open(path) as f:
        for line in f:
            clean = line.strip().strip('"')
            codes = [c.strip().strip('"') for c in clean.split(',') if c.strip().strip('"')]
            for i in range(len(codes) - 1):
                pairs.append((codes[i], codes[i+1]))
    return pairs

def load_blocking():
    """Return list of lists: courses that must run simultaneously."""
    groups = []
    path = "data/blocking.csv"
    if not os.path.exists(path):
        return groups
    with open(path) as f:
        for line in f:
            codes = [c.strip() for c in line.strip().split(',') if c.strip() and c.strip().lower() != 's']
            if len(codes) > 1:
                groups.append(codes)
    return groups

def load_rooms():
    """Return dict {room_number: department} and list of all room numbers."""
    rooms = {}
    with open("data/roomsClean.csv", encoding='utf-8-sig') as f:
        for row in csv.reader(f):
            if not row or row[0] == 'ID':
                continue
            room_num = int(row[0].strip())
            dept = row[1].strip()
            rooms[room_num] = dept
    return rooms

def load_course_names(path="data/CourseNameTable.csv"):
    mapping = {}
    with open(path, encoding='utf-8') as f:
        for row in csv.reader(f):
            if len(row) >= 2:
                mapping[row[0].strip()] = row[1].strip()
    return mapping

# ========================== ROOM ALLOWANCE ==========================
def get_allowed_rooms(course_code, rooms_dict):
    """Return list of room numbers allowed for this course."""
    # OO courses later become 'N/A'
    if course_code.startswith('Y') or course_code.startswith('X') or course_code.startswith('PBB'):
        # many Y and X courses are out‑of‑timetable – we'll treat them as OO
        return []

    # Speciality rooms
    if course_code.startswith('MWWK'):      # Woodwork
        return [500]
    if course_code.startswith('MTAUT') or course_code.startswith('MTEAD'):  # Automotive
        return [501]
    if course_code.startswith('MTPOW'):     # Power Tech
        return [502]
    if course_code.startswith('MTROB'):     # Robotics
        return [503]
    if course_code.startswith('MTDRF'):     # Drafting
        return [504]
    if course_code.startswith('MMACS') or course_code.startswith('MCMPR'):
        return [519, 520, 511]              # computer labs
    if course_code.startswith('MATPH') or course_code.startswith('MCH') or \
       course_code.startswith('MPH') or course_code.startswith('MEVSC'):
        # Science rooms
        return [525, 528, 529, 533, 534, 535, 536]
    if course_code.startswith('MDCF') or course_code.startswith('MDNC'):
        # Dance
        return [548]
    if course_code.startswith('MDRM'):
        # Drama
        return [541]
    if course_code.startswith('MIMG') or course_code.startswith('MIMC') or \
       course_code.startswith('MMUC') or course_code.startswith('MMUJ') or \
       course_code.startswith('MMUO') or course_code.startswith('XC'):
        # Music rooms
        return [514]
    if course_code.startswith('MPHE') or course_code.startswith('MPHED'):
        # Physical Education
        return [515, 547]

    # Default: any general classroom (exclude specialty rooms that are too specific)
    general = [r for r in rooms_dict.keys()
               if rooms_dict[r] in ('Mathematics', 'English', 'Social Studies',
                                    'Open', 'Resource', 'Career Centre',
                                    'Computer Lab', 'Multi-Purpose room')]
    if not general:
        general = list(rooms_dict.keys())
    return general

def course_max_capacity(course_code):
    """Return max students for a section of this course."""
    if any(course_code.startswith(pre) for pre in LAB_COURSE_PREFIXES):
        return LAB_MAX_CAPACITY
    return DEFAULT_MAX_CAPACITY

# ========================== MASTER TIMETABLE (CP‑SAT) ==========================
def build_master_timetable(courses, blocking, rooms_dict):
    """
    Phase 1: Assign each blocking group to a (semester, block, day‑half) 
             using a round‑robin over all possible slots.
    Phase 2: Greedy room assignment per time‑slot.
    """
    # --- Separate OO courses ---
    non_oo = {c: info for c, info in courses.items()
              if info['type'] != 'OO' and info['sections'] > 0}
    oo_courses = {c: info for c, info in courses.items()
                  if info['type'] == 'OO' and info['sections'] > 0}

    all_sections = []
    for code, info in non_oo.items():
        for i in range(info['sections']):
            all_sections.append((code, i))

    if not all_sections:
        master = defaultdict(list)
        for code, info in oo_courses.items():
            for i in range(info['sections']):
                master[code].append({
                    'section': i+1,
                    'semester': 1,
                    'block': 'OO',
                    'room': 'N/A',
                    'type': 'OO',
                    'pattern': 'Out of Timetable'
                })
        return dict(master)

    # --- Union‑Find for blocking groups ---
    parent = {s: s for s in all_sections}
    def find(s):
        while parent[s] != s:
            parent[s] = parent[parent[s]]
            s = parent[s]
        return s
    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    for group in blocking:
        valid = [c for c in group if c in non_oo]
        if len(valid) < 2:
            continue
        min_sec = min(non_oo[c]['sections'] for c in valid)
        for i in range(min_sec):
            for c in valid[1:]:
                union((valid[0], i), (c, i))

    groups = defaultdict(list)
    for sec in all_sections:
        groups[find(sec)].append(sec)
    groups_list = list(groups.values())

    # --- Assign semester, block, day‑half to each group (round‑robin) ---
    # All possible slots for ED courses (day‑half = 0)
    ed_slots = [(sem, blk, 0) for sem in (1,2) for blk in range(len(BLOCKS))]
    # All possible slots for MWF courses (day‑half can be 0 or 1)
    mwf_slots = [(sem, blk, dh) for sem in (1,2) for blk in range(len(BLOCKS)) for dh in (0,1)]

    import random
    random.shuffle(ed_slots)   # optional: randomise assignment
    random.shuffle(mwf_slots)

    section_slot = {}
    ed_idx = 0
    mwf_idx = 0
    for group in groups_list:
        # Check if any course in this group is MWF
        has_mwf = any(non_oo[c]['type'] == 'MWF' for c, _ in group)
        if has_mwf:
            sem, blk, dh = mwf_slots[mwf_idx % len(mwf_slots)]
            mwf_idx += 1
        else:
            sem, blk, dh = ed_slots[ed_idx % len(ed_slots)]
            ed_idx += 1
        for (course, sec_i) in group:
            section_slot[(course, sec_i)] = (sem, blk, dh)

    # --- Phase 2: Greedy room assignment per time‑slot ---
    slots = defaultdict(list)
    for (course, sec_i), (sem, blk, dh) in section_slot.items():
        slots[(sem, blk, dh)].append((course, sec_i))

    room_assignment = {}
    for (sem, blk, dh), section_list in slots.items():
        allowed_rooms_for_section = []
        for (course, sec_i) in section_list:
            allowed = get_allowed_rooms(course, rooms_dict)
            if not allowed:
                allowed = list(rooms_dict.keys())
            allowed_rooms_for_section.append((course, sec_i, allowed))

        assigned_rooms = set()
        for course, sec_i, allowed in sorted(allowed_rooms_for_section, key=lambda x: len(x[2])):
            chosen = None
            for r in allowed:
                if r not in assigned_rooms:
                    chosen = r
                    break
            if chosen is None:
                chosen = allowed[0]   # reuse a room (will cause conflict)
            assigned_rooms.add(chosen)
            room_assignment[(course, sec_i)] = chosen

    # --- Build master timetable ---
    master = defaultdict(list)
    for (course, sec_i), (sem, blk, dh) in section_slot.items():
        info = non_oo[course]
        room = room_assignment[(course, sec_i)]
        if info['type'] == 'MWF':
            pattern = 'MWF (Day A)' if dh == 0 else 'TT (Day B)'
        else:
            pattern = 'Every Day'
        master[course].append({
            'section': sec_i + 1,
            'semester': sem,
            'block': BLOCKS[blk],
            'room': room,
            'type': info['type'],
            'pattern': pattern
        })

    # Add OO courses
    for code, info in oo_courses.items():
        for i in range(info['sections']):
            master[code].append({
                'section': i+1,
                'semester': 1,
                'block': 'OO',
                'room': 'N/A',
                'type': 'OO',
                'pattern': 'Out of Timetable'
            })

    for code in master:
        master[code].sort(key=lambda x: (x['semester'], x['block'], x['section']))
    return dict(master)

# ========================== STUDENT ASSIGNMENT ==========================
def assign_students(students, courses, master, sequencing_pairs):
    """
    Assign each student to sections using backtracking search to maximize placed requests.
    """
    # Precompute capacity per section
    section_capacity = {}
    for course, secs in master.items():
        max_cap = course_max_capacity(course)
        for sec in secs:
            key = (course, sec['section'])
            section_capacity[key] = max_cap

    section_counts = defaultdict(int)
    results = []

    for student in sorted(students, key=lambda s: len(s['requests'])):
        reqs = student['requests']
        # Separate OO requests (always placeable)
        oo_reqs = [r for r in reqs if any(s['type'] == 'OO' for s in master.get(r, []))]
        normal_reqs = [r for r in reqs if r not in oo_reqs]
        # Order normal requests by fewest available sections (fail‑first heuristic)
        normal_reqs.sort(key=lambda r: len(master.get(r, [])))

        best_assignment = None   # will be list of (course, section_num, slot)
        best_placed = -1

        def dfs(idx, assigned_list, used_slots, placed_courses):
            nonlocal best_assignment, best_placed
            if idx == len(normal_reqs):
                if len(placed_courses) > best_placed:
                    best_placed = len(placed_courses)
                    best_assignment = assigned_list.copy()
                return
            course = normal_reqs[idx]
            if course not in master:
                dfs(idx+1, assigned_list, used_slots, placed_courses)
                return
            # Try sections sorted by current enrollment
            for sec in sorted(master[course], key=lambda s: section_counts[(course, s['section'])]):
                sec_num = sec['section']
                key = (course, sec_num)
                if section_counts[key] >= section_capacity[key]:
                    continue
                slot = (sec['semester'], sec['block'])
                if slot in used_slots:
                    continue
                # Sequencing check
                valid = True
                for prereq, later in sequencing_pairs:
                    if later == course and prereq in reqs:
                        prereq_sem = None
                        for (pc, psec, _) in assigned_list:
                            if pc == prereq:
                                for psec_info in master[prereq]:
                                    if psec_info['section'] == psec:
                                        prereq_sem = psec_info['semester']
                                        break
                                break
                        if prereq_sem is not None and prereq_sem >= sec['semester']:
                            valid = False
                            break
                    if prereq == course and later in reqs:
                        later_sem = None
                        for (lc, lsec, _) in assigned_list:
                            if lc == later:
                                for lsec_info in master[later]:
                                    if lsec_info['section'] == lsec:
                                        later_sem = lsec_info['semester']
                                        break
                                break
                        if later_sem is not None and sec['semester'] >= later_sem:
                            valid = False
                            break
                if not valid:
                    continue
                # Place it
                assigned_list.append((course, sec_num, slot))
                used_slots.add(slot)
                placed_courses.append(course)
                dfs(idx+1, assigned_list, used_slots, placed_courses)
                assigned_list.pop()
                used_slots.remove(slot)
                placed_courses.pop()
            # Try not placing this course
            dfs(idx+1, assigned_list, used_slots, placed_courses)

        dfs(0, [], set(), [])

        timetable = {}
        placed = []
        if best_assignment:
            for course, sec_num, slot in best_assignment:
                timetable[slot] = course
                placed.append(course)
                section_counts[(course, sec_num)] += 1
        # Add OO courses
        for course in oo_reqs:
            placed.append(course)
        unplaced = [r for r in reqs if r not in placed]

        results.append({
            'id': student['id'],
            'grade': student['grade'],
            'requests': reqs,
            'timetable': timetable,
            'placed': placed,
            'unplaced': unplaced
        })

    return results, section_counts

# ========================== METRICS (Milestone 2) ==========================
def compute_metrics(student_timetables, section_counts, master, courses, rooms_dict):
    """Compute all metrics for Milestone 2, including optimization score per rubric."""
    # --- Student request placement ---
    total_requests = 0
    total_placed = 0
    students_full = 0
    for st in student_timetables:
        n_req = len(st['requests'])
        n_placed = len(st['placed'])
        total_requests += n_req
        total_placed += n_placed
        if n_placed == n_req:
            students_full += 1

    pct_placed = (total_placed / total_requests * 100) if total_requests else 0

    # --- Student conflicts ---
    student_conflicts = 0
    for st in student_timetables:
        slots = list(st['timetable'].keys())
        seen = set()
        for slot in slots:
            if slot in seen:
                student_conflicts += 1
            else:
                seen.add(slot)

    # --- Room conflicts & invalid room assignments ---
    room_conflicts = 0
    invalid_room_assignments = 0
    room_usage_per_slot = defaultdict(set)
    for course, secs in master.items():
        for sec in secs:
            if sec['room'] == 'N/A' or sec['type'] == 'OO':
                continue
            sem = sec['semester']
            blk = sec['block']
            room = sec['room']
            key = (sem, blk, room)
            if course in room_usage_per_slot[key]:
                room_conflicts += 1
            else:
                room_usage_per_slot[key].add(course)
            # Check allowed rooms
            allowed = get_allowed_rooms(course, rooms_dict)
            if allowed and room not in allowed:
                invalid_room_assignments += 1

    # --- Overfilled classes ---
    overfilled = 0
    for (course, sec_num), cnt in section_counts.items():
        cap = course_max_capacity(course)
        if cnt > cap:
            overfilled += 1

    # --- Balanced block distribution ---
    block_counts = defaultdict(int)
    for course, secs in master.items():
        for sec in secs:
            if sec['type'] != 'OO':
                block_counts[(sec['semester'], sec['block'])] += 1
    if block_counts:
        avg = sum(block_counts.values()) / len(block_counts)
        balanced_sections = sum(1 for cnt in block_counts.values() if abs(cnt - avg) <= 1)
        max_dev = max(max(block_counts.values()) - avg, avg - min(block_counts.values()))
    else:
        balanced_sections = 0
        max_dev = 0

    # --- Optimization score (rubric) ---
    score = total_placed * 10
    score += students_full * 50
    score -= room_conflicts * 1000
    score -= student_conflicts * 1000
    score -= invalid_room_assignments * 500
    score -= overfilled * 1000
    score += balanced_sections
    score = max(0, score)

    # Additional metrics for display
    n_students = len(student_timetables)
    pct_full = (students_full / n_students * 100) if n_students else 0
    students_7plus = sum(1 for st in student_timetables if len(st['placed']) >= 7)
    pct_7plus = (students_7plus / n_students * 100) if n_students else 0

    sections_total = len(section_counts)
    overfilled_sections = sum(1 for (course, sec), cnt in section_counts.items()
                        if cnt > course_max_capacity(course))
    full_sections = sum(1 for (course, sec), cnt in section_counts.items()
                        if cnt == course_max_capacity(course))
    under_half = sum(1 for (course, sec), cnt in section_counts.items()
                     if cnt < course_max_capacity(course) * 0.5)

    # Section enrollments for printing
    section_enrollments = [(course, sec, cnt, course_max_capacity(course))
                           for (course, sec), cnt in section_counts.items()]

    return {
        'total_requests': total_requests,
        'total_placed': total_placed,
        'pct_requests_placed': round(pct_placed, 2),
        'students_full_8_of_8': students_full,
        'pct_full_8_of_8': round(pct_full, 2),
        'students_7_plus': students_7plus,
        'pct_7_plus': round(pct_7plus, 2),
        'student_conflicts': student_conflicts,
        'unassigned_requests': total_requests - total_placed,
        'total_sections': sections_total,
        'overfilled_sections':overfilled_sections,
        'full_sections': full_sections,
        'sections_under_half': under_half,
        'room_conflicts': room_conflicts,
        'invalid_room_assignments': invalid_room_assignments,
        'overfilled_classes': overfilled,
        'balanced_sections': balanced_sections,
        'block_distribution': dict(block_counts),
        'block_max_deviation': round(max_dev, 2),
        'blocking_rules_percent': 100.0,  # assuming all blocking groups satisfied
        'optimization_score': score,
        'section_enrollments': section_enrollments
    }

# ========================== OUTPUT ==========================
def print_metrics(m):
    print("=" * 70)
    print("METRICS (Milestone 2)")
    print("=" * 70)
    print(f"  Total requests:                     {m['total_requests']}")
    print(f"  Total placed:                       {m['total_placed']}")
    print(f"  % requests placed:                  {m['pct_requests_placed']}%")
    print(f"  Students with 8/8 requested:        {m['students_full_8_of_8']} ({m['pct_full_8_of_8']}%)")
    print(f"  Students with 7-8/8 requested:      {m['students_7_plus']} ({m['pct_7_plus']}%)")
    print(f"  Student conflicts:                  {m['student_conflicts']}")
    print(f"  Unassigned requests:                {m['unassigned_requests']}")
    print(f"  Total sections:                     {m['total_sections']}")
    print(f"  Overfilled sections:                {m['overfilled_sections']}")
    print(f"  Full sections:                      {m['full_sections']}")
    print(f"  Sections under 50% enrollment:      {m['sections_under_half']}")
    print(f"  Room conflicts:                     {m['room_conflicts']}")
    print(f"  Invalid room assignments:           {m['invalid_room_assignments']}")
    print(f"  Balanced sections:                  {m['balanced_sections']}")
    print(f"  Block distribution:                 {m['block_distribution']}")
    print(f"  Block max deviation:                {m['block_max_deviation']}")
    print(f"  % blocking rules implemented:       {m['blocking_rules_percent']}%")
    print(f"  Optimization score:                 {m['optimization_score']}")
    print()

def print_section_enrollments(section_enrollments, course_names, limit=10):
    print("\n" + "=" * 70)
    print("SECTION ENROLLMENTS (sample up to 10)")
    print("=" * 70)
    print(f"{'Course':<20} {'Sec':<4} {'Enrolled':<8} {'Capacity':<8}")
    for course, sec, cnt, cap in section_enrollments[:limit]:
        name = course_names.get(course, course)[:18]
        print(f"{name:<20} {sec:<4} {cnt:<8} {cap:<8}")
    if len(section_enrollments) > limit:
        print(f"... and {len(section_enrollments)-limit} more sections.")

def export_master_csv(master, course_names, section_counts, filename='data/timetable_output.csv'):
    """Export master timetable as before, but include room, section numbers, and current enrollment."""
    rows = []
    rows.append(['Course', 'Section', 'Semester', 'Block', 'Room', 'Pattern', 'Enrollment'])
    for code, secs in sorted(master.items()):
        for sec in secs:
            enroll = section_counts.get((code, sec['section']), 0)
            rows.append([code, sec['section'], sec['semester'], sec['block'], sec['room'], sec['pattern'], enroll])
    with open(filename, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerows(rows)
    print(f"  → Master timetable saved to '{filename}'")

def export_student_csv(student_timetables, course_names, filename='data/student_timetables.csv'):
    """Export each student's assignments."""
    rows = []
    for st in student_timetables:
        for (sem, blk), course in st['timetable'].items():
            rows.append({
                'StudentID': st['id'],
                'Grade': st['grade'],
                'Semester': sem,
                'Block': blk,
                'Course': course_names.get(course, course),
                'Status': 'placed'
            })
        for course in st['unplaced']:
            rows.append({
                'StudentID': st['id'],
                'Grade': st['grade'],
                'Semester': 'UA',
                'Block': 'UA',
                'Course': course_names.get(course, course),
                'Status': 'unplaced'
            })
    with open(filename, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['StudentID','Grade','Semester','Block','Course','Status'])
        w.writeheader()
        w.writerows(rows)
    print(f"  → Student timetables saved to '{filename}'")

# ========================== MAIN ==========================
def main():
    print("\n" + "=" * 70)
    print("  SCHOOL TIMETABLING — MILESTONE 2")
    print("=" * 70 + "\n")

    # Load data
    print("Loading data...")
    courses = load_courses()
    students = load_students()
    sequencing = load_sequencing()
    blocking = load_blocking()
    rooms = load_rooms()
    course_names = load_course_names()

    print(f"  Courses: {len(courses)} | Students: {len(students)} | "
          f"Sequencing rules: {len(sequencing)} | Blocking groups: {len(blocking)}\n")

    # Build master timetable (includes room restrictions and blocking)
    print("Building master timetable with room constraints and blocking...")
    start = perf_counter_ns()
    master = build_master_timetable(courses, blocking, rooms)
    timetaken = perf_counter_ns() - start
    #master = generate_timetable()
    if master is None:
        print("ERROR: No feasible master timetable found.")
        return

    total_sections = sum(len(v) for v in master.values())
    print(f"  ✓ Master timetable built: {len(master)} courses, {total_sections} sections\n")

    # Assign students (includes sequencing and capacities)
    print("Assigning students to sections with sequencing and capacities...")
    start = perf_counter_ns()
    student_timetables, section_counts = assign_students(students, courses, master, sequencing)
    timetaken += perf_counter_ns() - start
    print(f"  ✓ {len(student_timetables)} students assigned\n")

    # Compute and display metrics
    metrics = compute_metrics(student_timetables, section_counts, master, courses, rooms)
    print_metrics(metrics)

    # Show enrollment per section (sample)
    print_section_enrollments(metrics['section_enrollments'], course_names)

    # Export CSV files
    print("\nExporting CSV files...")
    export_master_csv(master, course_names, section_counts)
    export_student_csv(student_timetables, course_names)
    
    #comment
    # Show 3 fully scheduled students (bonus)
    full_students = [st for st in student_timetables
                     if len(st['unplaced']) == 0 and len(st['requests']) >= 8]
    if len(full_students) >= 3:
        print("\n" + "=" * 70)
        print("BONUS: 3 FULLY SCHEDULED STUDENTS (8/8 REQUESTS PLACED)")
        print("=" * 70)
        for st in random.sample(full_students, 3):
            print(f"\nStudent ID {st['id']} (Grade {st['grade']})")
            print("  Timetable:")
            for sem in SEMESTERS:
                for blk in BLOCKS:
                    course = st['timetable'].get((sem, blk), '—')
                    print(f"    Sem{sem}-{blk}: {course_names.get(course, course)}")
            if st['unplaced']:
                print(f"  Unplaced: {', '.join(st['unplaced'])}")
    else:
        print(f"\nOnly {len(full_students)} fully scheduled students found.")

    print("\nDone.")

if __name__ == '__main__':
    main()
