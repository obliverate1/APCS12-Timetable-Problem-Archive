"""
School Timetabling Problem — Milestone 1
=========================================
Builds a master timetable (course → semester, block, room) then assigns
each student to one section per requested course, checking for block conflicts.
"""

import csv
import os
import random
from collections import defaultdict
from ortools.sat.python import cp_model


""" 
READ ME!!!!!!!!!!!!!!!!!!:
Make sure to have the cleanedstudentrequests.csv, 
sections.csv, sequencing.csv, and blocking.csv files in a 'data' folder
"""

# if band is in time table, assume class size is 30


# ── Constants ──────────────────────────────────────────────────────────────────
BLOCKS      = ['A', 'B', 'C', 'D']
SEMESTERS   = [1, 2]
ROOM_MIN    = 500
ROOM_MAX    = 548
DATA_DIR    = 'data'
MAX_CLASS_SIZE  = 30
MIN_CLASS_SIZE = 15


# ══════════════════════════════════════════════════════════════════════════════
# STEP 1 — LOAD DATA
# ══════════════════════════════════════════════════════════════════════════════

def load_courses():
    """
    Returns:
        courses  dict  {course_code: {'sections': int, 'type': str}}
    """
    courses = {}
    path = "data/sections.csv"
    with open(path) as f:
        for row in csv.reader(f):
            if not row:
                continue
            code     = row[0].strip()
            num_sec  = int(row[1].strip())
            sched    = row[2].strip().upper() if len(row) > 2 and row[2].strip() else 'ED'
            courses[code] = {'sections': num_sec, 'type': sched}
    return courses


def load_students():
    """
    Returns:
        students  list of dicts
        [{'id': int, 'grade': int, 'requests': [str, ...]}, ...]
    """
    students = []
    path = "data/cleanedstudentrequests.csv"

    current_student = None

    with open(path, newline='', encoding='utf-8-sig') as f:
        reader = csv.reader(f)

        for row in reader:
            # Skip completely empty rows
            if not row:
                continue

            col0 = row[0].strip()

            # Detect a new student block
            if col0 == 'ID':
                # Save the previous student before starting a new one
                if current_student is not None:
                    students.append(current_student)

                # Extract ID and Grade
                student_id = int(row[1].strip())
                grade = int(row[3].strip()) if len(row) > 3 and row[3].strip().isdigit() else 0

                # Initialize the new student record
                # Note: Storing Grade in the 'grade' field based on the CSV data
                current_student = {
                    'id': student_id,
                    'grade': grade, 
                    'requests': []
                }

            # Skip the recurring 'Course' header rows or rows with empty first columns
            elif col0 == 'Course' or not col0:
                continue

            # If it's not 'ID' and not 'Course', it's a requested course code
            elif current_student is not None:
                current_student['requests'].append(col0)

        # Append the very last student in the file after the loop finishes
        if current_student is not None:
            students.append(current_student)

    return students


def load_sequencing():
    """Returns list of (prerequisite_code, later_code) pairs."""
    pairs = []
    path = "data/sequencing.csv"
    if not os.path.exists(path):
        return pairs
    with open(path) as f:
        for line in f:
            clean = line.strip().strip('"')
            codes = [c.strip().strip('"') for c in clean.split(',') if c.strip().strip('"')]
            for i in range(len(codes) - 1):
                pairs.append((codes[i], codes[i + 1]))
    return pairs


def load_blocking():
    """Returns list of lists — courses that must run simultaneously."""
    groups = []
    path = "data/blocking.csv"
    if not os.path.exists(path):
        return groups
    with open(path) as f:
        for line in f:
            codes = [c.strip() for c in line.strip().split(',')
                     if c.strip() and c.strip().lower() != 's']
            if len(codes) > 1:
                groups.append(codes)
    return groups

def load_course_names(path="data/CourseNameTable.csv"):
    mapping = {}

    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.reader(f)

        for row in reader:
            if len(row) < 2:
                continue

            code = row[0].strip()
            name = row[1].strip()

            mapping[code] = name

    return mapping

# ══════════════════════════════════════════════════════════════════════════════
# STEP 2 — BUILD MASTER TIMETABLE  (CP-SAT)
# ══════════════════════════════════════════════════════════════════════════════

def build_master_timetable(courses, sequencing, blocking):
    """
    Returns master_timetable:
        { course_code: [ {'semester': int, 'block': str, 'room': int|'N/A',
                          'type': str, 'pattern': str},  ...one per section... ]
        }
    or None if no solution found.
    """
    # ── Enumerate all (course, section_index) pairs ──────────────────────────
    all_sections = []
    for code, info in courses.items():
        for i in range(info['sections']):
            all_sections.append((code, i))

    # ── Union-Find for simultaneous-blocking groups ───────────────────────────
    parent = {s: s for s in all_sections}

    def find(s):
        if parent[s] != s:
            parent[s] = find(parent[s])
        return parent[s]

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    for group in blocking:
        valid = [c for c in group if c in courses and courses[c]['sections'] > 0]
        if len(valid) < 2:
            continue
        min_sec = min(courses[c]['sections'] for c in valid)
        for i in range(min_sec):
            for c in valid[1:]:
                union((valid[0], i), (c, i))

    # ── seque

    # ── Group into sessions ───────────────────────────────────────────────────
    sessions_dict = defaultdict(list)
    for sec in all_sections:
        sessions_dict[find(sec)].append(sec)
    sessions = list(sessions_dict.values())

    def session_type(sess):
        types = {courses[c]['type'] for c, _ in sess}
        for t in ('ED', 'MWF', 'OO'):
            if t in types:
                return t
        return 'ED'

    session_types = [session_type(s) for s in sessions]

    # ── CP-SAT model ──────────────────────────────────────────────────────────
    model = cp_model.CpModel()

    sem_vars       = []
    block_vars     = []
    room_vars      = []
    day_half_vars  = {}
    global_slots   = []

    for idx, s_type in enumerate(session_types):
        sem   = model.NewIntVar(1, 2, f'sem_{idx}')
        sem_vars.append(sem)

        if s_type == 'OO':
            block_vars.append(model.NewIntVar(0, 0, f'blk_{idx}'))
            room_vars.append(model.NewIntVar(0, 0, f'rm_{idx}'))
            day_half_vars[idx] = None
        else:
            blk  = model.NewIntVar(0, len(BLOCKS) - 1, f'blk_{idx}')
            room = model.NewIntVar(ROOM_MIN, ROOM_MAX, f'rm_{idx}')
            block_vars.append(blk)
            room_vars.append(room)

            if s_type == 'ED':
                day_half_vars[idx] = None
                for dh in (0, 1):
                    gs = model.NewIntVar(0, 300_000, f'gs_{idx}_d{dh}')
                    model.Add(gs == room + 1000 * blk + 10000 * sem + 100000 * dh)
                    global_slots.append(gs)
            else:  # MWF
                dh  = model.NewIntVar(0, 1, f'dh_{idx}')
                day_half_vars[idx] = dh
                gs  = model.NewIntVar(0, 300_000, f'gs_{idx}')
                model.Add(gs == room + 1000 * blk + 10000 * sem + 100000 * dh)
                global_slots.append(gs)

    if global_slots:
        model.AddAllDifferent(global_slots)

    # ── Sequencing constraints ────────────────────────────────────────────────
    # NOTE: Sequencing rules span multiple school years (e.g. French 9→10→11→12).
    # Applying them as hard same-year semester constraints (sem1 < sem2) makes
    # the model infeasible for 3+ course chains.  They are loaded and reported
    # but not enforced in the solver for Milestone 1.
    sec_to_sess = {}
    for idx, sess in enumerate(sessions):
        for sec in sess:
            sec_to_sess[sec] = idx

    # ── Solve ─────────────────────────────────────────────────────────────────
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 60.0
    status = solver.Solve(model)

    if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        return None

    # ── Extract results ───────────────────────────────────────────────────────
    master = defaultdict(list)   # course_code → list of section dicts

    for idx, sess in enumerate(sessions):
        s_type = session_types[idx]
        sem    = solver.Value(sem_vars[idx])

        if s_type == 'OO':
            blk_str  = 'OO'
            room_val = 'N/A'
            pattern  = 'Out of Timetable'
        else:
            blk_str  = BLOCKS[solver.Value(block_vars[idx])]
            room_val = solver.Value(room_vars[idx])
            if s_type == 'ED':
                pattern = 'Every Day'
            else:
                dh      = solver.Value(day_half_vars[idx])
                pattern = 'MWF (Day A)' if dh == 0 else 'TT (Day B)'

        for course, sec_i in sess:
            master[course].append({
                'section':  sec_i + 1,
                'semester': sem,
                'block':    blk_str,
                'room':     room_val,
                'type':     s_type,
                'pattern':  pattern
            })

    # Sort each course's sections for readability
    for code in master:
        master[code].sort(key=lambda x: (x['semester'], x['block'], x['section']))

    return dict(master)


# ══════════════════════════════════════════════════════════════════════════════
# STEP 3 — ASSIGN STUDENTS TO SECTIONS
# ══════════════════════════════════════════════════════════════════════════════

def assign_students(students, courses, master):
    """
    For each student, try to place every requested course into their personal
    timetable (8 slots: sem×block).  Conflict = two courses in the same slot.

    Returns:
        student_timetables  list of dicts, one per student:
            {
              'id':        int,
              'grade':       int,
              'requests':  [str, ...],
              'timetable': { (sem, block): course_code },   # placed courses
              'placed':    [str, ...],
              'unplaced':  [str, ...]    # 'unassigned'
            }
    """
    results = []
    section_counts = defaultdict(int)

    for student in students:
        timetable = {}         # (sem, block) → course_code
        placed    = []
        unplaced  = []

        for req in student['requests']:
            # Skip courses not in master (unknown/truncated codes, 0-section courses)
            if req not in master:
                unplaced.append(req)
                continue

            sections_for_course = master[req]
            if not sections_for_course:
                unplaced.append(req)
                continue

            # OO courses get a special slot that never conflicts
            # We'll just mark them placed without using a block slot
            oo_sections = [s for s in sections_for_course if s['type'] == 'OO']
            if oo_sections:
                placed.append(req)
                timetable[('OO', req)] = req
                continue

            # Try each section; pick first that has no slot conflict
            assigned = False
            for sec in sorted(sections_for_course, key=lambda s: section_counts[(req, s['section'])]):
                section_key = (req, sec['section'])


                if section_counts[section_key] < MAX_CLASS_SIZE:

                    slot = (sec['semester'], sec['block'])

                    if slot not in timetable:
                        timetable[slot] = req
                        placed.append(req)

                        section_counts[section_key] += 1
                        assigned = True
                        break

            if not assigned:
                unplaced.append(req)

        results.append({
            'id':        student['id'],
            'grade':       student['grade'],
            'requests':  student['requests'],
            'timetable': timetable,
            'placed':    placed,
            'unplaced':  unplaced
        })

    return results, section_counts


# ══════════════════════════════════════════════════════════════════════════════
# STEP 4 — METRICS
# ══════════════════════════════════════════════════════════════════════════════

def compute_metrics(student_timetables):
    total_requests  = 0
    total_placed    = 0
    full_8          = 0   # all 8 non-OO requests placed
    half_or_more    = 0   # ≥50% placed

    for st in student_timetables:
        n_req    = len(st['requests'])
        n_placed = len(st['placed'])
        total_requests += n_req
        total_placed   += n_placed

        if n_placed >= n_req and n_req >= 8:
            full_8 += 1
        if n_req > 0 and (n_placed / n_req) >= 0.5:
            half_or_more += 1

    n_students = len(student_timetables)
    pct_placed = (total_placed / total_requests * 100) if total_requests else 0
    pct_full8  = (full_8 / n_students * 100)       if n_students else 0
    pct_half   = (half_or_more / n_students * 100) if n_students else 0

    # Optimization score: weighted combination
    score = round(0.6 * pct_placed + 0.3 * pct_full8 + 0.1 * pct_half, 2)

    return {
        'total_requests':        total_requests,
        'total_placed':          total_placed,
        'pct_requests_placed':   round(pct_placed, 2),
        'students_full_8_of_8':  full_8,
        'pct_full_8_of_8':       round(pct_full8, 2),
        'students_half_plus':    half_or_more,
        'pct_half_plus':         round(pct_half, 2),
        'optimization_score':    score
    }


# ══════════════════════════════════════════════════════════════════════════════
# STEP 5 — OUTPUT
# ══════════════════════════════════════════════════════════════════════════════

def print_data_structures(courses, students, master):
    print("=" * 70)
    print("DATA STRUCTURES — SIZES AND SAMPLES")
    print("=" * 70)

    print(f"\n[1] COURSES  ({len(courses)} courses loaded from sections.csv)")
    print(f"    Keys: course_code → {{sections, type}}")
    sample_courses = list(courses.items())[:5]
    for k, v in sample_courses:
        print(f"    {k!r:20s} → {v}")

    print(f"\n[2] STUDENTS  ({len(students)} students loaded from Course_Selection_by_student.csv)")
    print(f"    Keys: id, grade, requests (list of course codes)")
    for s in students[:3]:
        print(f"    ID {s['id']} (grad {s['grade']}): {len(s['requests'])} requests → {s['requests'][:4]}{'...' if len(s['requests']) > 4 else ''}")

    if master:
        total_sections = sum(len(v) for v in master.values())
        print(f"\n[3] MASTER TIMETABLE  ({len(master)} courses placed, {total_sections} total sections)")
        print(f"    Keys: course_code → [list of section dicts]")
        for code, secs in list(master.items())[:4]:
            print(f"    {code!r:20s} → {secs}")
    print()


def print_master_timetable(master):
    print("=" * 70)
    print("MASTER TIMETABLE")
    print("=" * 70)
    print(f"{'Course':<14} {'Sec':<4} {'Sem':<4} {'Block':<6} {'Room':<6} {'Type':<4} Pattern")
    print("-" * 70)

    # Sort: semester → block → course
    rows = []
    for code, secs in master.items():
        for sec in secs:
            rows.append((code, sec))
    rows.sort(key=lambda x: (
        x[1]['semester'],
        x[1]['block'],
        999 if x[1]['room'] == 'N/A' else x[1]['room'],
        x[0]
    ))

    for code, sec in rows:
        print(f"{code:<14} {sec['section']:<4} {sec['semester']:<4} "
              f"{sec['block']:<6} {str(sec['room']):<6} {sec['type']:<4} {sec['pattern']}")
    print()


def print_student_timetable(st):
    """Pretty-print one student's individual timetable."""
    print(f"\n{'─'*60}")
    print(f"  Student ID: {st['id']}   Grad Year: {st['grade']}")
    print(f"  Requests: {len(st['requests'])}   Placed: {len(st['placed'])}   "
          f"Unplaced: {len(st['unplaced'])}")
    print(f"{'─'*60}")

    # Regular block slots
    print(f"  {'Slot':<14} Course")
    print(f"  {'────':<14} ──────")
    for sem in SEMESTERS:
        for blk in BLOCKS:
            slot  = (sem, blk)
            course = st['timetable'].get(slot, '—')
            print(f"  Sem{sem}-Block {blk}    {course}")

    # OO courses
    oo = [v for k, v in st['timetable'].items() if isinstance(k, tuple) and k[0] == 'OO']
    if oo:
        print(f"  Out-of-Timetable:   {', '.join(oo)}")

    # Unplaced
    if st['unplaced']:
        print(f"  UNASSIGNED:         {', '.join(st['unplaced'])}")


def export_master_csv(master, course_names, filename='master_timetable.csv'):
    """
    Export master timetable in grid format:

        Semester 1                  Semester 2
        A  B  C  D                 A  B  C  D
        ------------------         ------------------
        course lists under each block
    """

    # Create structure:
    # grid[(semester, block)] = [course strings]
    grid = defaultdict(list)

    for course, sections in master.items():
        for sec in sections:

            # Skip OO courses
            if sec['block'] == 'OO':
                continue

            sem = sec['semester']
            blk = sec['block']

            entry = f"{course_names.get(course, course)} (S{sec['section']})"
            grid[(sem, blk)].append(entry)

    # Find tallest column
    max_rows = max(len(v) for v in grid.values()) if grid else 0

    # Prepare CSV rows
    rows = []

    # Header row 1
    rows.append([
        'Semester 1', '', '', '',
        'Semester 2', '', '', ''
    ])

    # Header row 2
    rows.append([
        'A', 'B', 'C', 'D',
        'A', 'B', 'C', 'D'
    ])

    # Data rows
    for i in range(max_rows):
        row = []

        # Semester 1
        for blk in BLOCKS:
            courses = grid[(1, blk)]
            row.append(courses[i] if i < len(courses) else '')

        # Semester 2
        for blk in BLOCKS:
            courses = grid[(2, blk)]
            row.append(courses[i] if i < len(courses) else '')

        rows.append(row)

    # Write CSV
    with open(filename, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerows(rows)

    print(f"  → Master timetable saved to '{filename}'")


def export_student_csv(student_timetables, course_names, filename='student_timetables.csv'):
    rows = []
    for st in student_timetables:
        # Regular block slots
        for sem in SEMESTERS:
            for blk in BLOCKS:
                slot   = (sem, blk)
                course = st['timetable'].get(slot, 'unassigned')
                rows.append({
                    'StudentID': st['id'],
                    'Grade':       st['grade'],
                    'Semester':  sem,
                    'Block':     blk,
                    'Course':    course_names.get(course, course),
                    'SlotType':  'regular'
                })
        # OO courses
        for k, v in st['timetable'].items():
            if isinstance(k, tuple) and k[0] == 'OO':
                rows.append({
                    'StudentID': st['id'],
                    'Grade':       st['grade'],
                    'Semester':  'OO',
                    'Block':     'OO',
                    'Course':    v,
                    'SlotType':  'out-of-timetable'
                })
        # Unplaced
        for c in st['unplaced']:
            rows.append({
                'StudentID': st['id'],
                'Grade':       st['grade'],
                'Semester':  'UA',
                'Block':     'UA',
                'Course':    c,
                'SlotType':  'UA'
            })
    with open(filename, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['StudentID','Grade','Semester','Block','Course','SlotType'])
        w.writeheader()
        w.writerows(rows)
    print(f"  → Student timetables saved to '{filename}'")


def print_metrics(m):
    print("=" * 70)
    print("METRICS")
    print("=" * 70)
    print(f"  Total course requests:              {m['total_requests']}")
    print(f"  Total placed:                       {m['total_placed']}")
    print(f"  % requests placed:                  {m['pct_requests_placed']}%")
    print(f"  Students with all requests placed:  {m['students_full_8_of_8']}  ({m['pct_full_8_of_8']}%)")
    print(f"  Students with ≥50% placed:          {m['students_half_plus']}  ({m['pct_half_plus']}%)")
    print(f"  Optimization score:                 {m['optimization_score']} / 100")
    print()


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    print("\n" + "=" * 70)
    print("  SCHOOL TIMETABLING — MILESTONE 1")
    print("=" * 70 + "\n")

    # ── Load ──────────────────────────────────────────────────────────────────
    print("Loading data...")
    courses    = load_courses()
    students   = load_students()
    sequencing = load_sequencing()
    blocking   = load_blocking()
    course_names = load_course_names()
    print(f"  Courses: {len(courses)}  |  Students: {len(students)}  |  "
          f"Sequencing rules: {len(sequencing)}  |  Blocking groups: {len(blocking)}\n")

    # ── Print data structures ─────────────────────────────────────────────────
    print_data_structures(courses, students, master=None)

    # ── Solve master timetable ────────────────────────────────────────────────
    print("Building master timetable (CP-SAT solver, up to 60s)...")
    master = build_master_timetable(courses, sequencing, blocking)

    if master is None:
        print("ERROR: Solver could not find a valid schedule. Exiting.")
        return

    print(f"  ✓ Master timetable solved — {len(master)} courses scheduled\n")

    # Update data structure printout now that master is available
    total_sections = sum(len(v) for v in master.values())
    print(f"[3] MASTER TIMETABLE  ({len(master)} courses, {total_sections} sections)")
    for code, secs in list(master.items())[:4]:
        print(f"    {code!r:20s} → {secs}")
    print()

    # ── Print master timetable ────────────────────────────────────────────────
    #print_master_timetable(master)

    # ── Assign students ───────────────────────────────────────────────────────
    print("Assigning students to sections...")
    student_timetables, section_counts = assign_students(students, courses, master)
    print(f"  ✓ {len(student_timetables)} students assigned\n")

    # ── Print a few sample student timetables ─────────────────────────────────
    print("=" * 70)
    print("SAMPLE STUDENT TIMETABLES (first 3 students)")
    print("=" * 70)
    for st in student_timetables[:3]:
        print_student_timetable(st)

    # ── BONUS — Show 3 fully scheduled students ────────────────────────────────
    full_students = [
        st for st in student_timetables
        if len(st['unplaced']) == 0 and len(st['requests']) >= 8
    ]

    if len(full_students) >= 3:

        print("\n" + "=" * 70)
        print("BONUS — 3 FULLY SCHEDULED STUDENTS (8/8 REQUESTS PLACED)")
        print("=" * 70)

        selected = random.sample(full_students, 3)

    for i, st in enumerate(selected, start=1):
        print(f"\nFULLY SCHEDULED STUDENT #{i}")
        print_student_timetable(st)

    else:
        print("\nNot enough fully scheduled students found.")
        print(f"Only found {len(full_students)} students with complete timetables.")

    # ── Metrics ───────────────────────────────────────────────────────────────
    print()
    metrics = compute_metrics(student_timetables)
    print_metrics(metrics)

    # ── Export CSVs ───────────────────────────────────────────────────────────
    print("Exporting CSVs...")
    export_master_csv(master, course_names)
    export_student_csv(student_timetables, course_names)
    print()
    print("Done!")


if __name__ == '__main__':
    main()
