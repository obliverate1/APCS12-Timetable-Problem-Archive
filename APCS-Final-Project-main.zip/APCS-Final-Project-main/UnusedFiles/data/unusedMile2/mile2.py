"""
School Timetabling Problem — Milestone 2 (Final)
Uses masterTimeTableMaker for timetable generation (flexible rooms, half‑fill constraint)
then applies student assignment and metrics.
"""
import csv, random, os
from collections import defaultdict
import masterTimeTableMaker

def assign_students(students, courses, master, seq_pairs):
    sec_cap = {}
    for course, secs in master.items():
        cap = masterTimeTableMaker.course_max_capacity(course)
        for sec in secs:
            sec_cap[(course, sec['section'])] = cap

    sec_counts = defaultdict(int)
    results = []

    seq_prereq = defaultdict(list)
    for pre, post in seq_pairs:
        seq_prereq[post].append(pre)

    for student in sorted(students, key=lambda s: len(s['requests'])):
        reqs = student['requests']
        alts = student.get('alternates', [])

        oo_placed = [r for r in reqs+alts
                     if r in master and master[r] and master[r][0]['type'] == 'OO']
        normal = [r for r in reqs if r not in oo_placed and r in master and master[r]]
        normal.sort(key=lambda r: len(master.get(r, [])))

        timetable = {}
        placed_list = list(oo_placed)
        placed_set = set(oo_placed)

        for course in normal:
            best_sec = None
            best_enroll = None
            for sec in master[course]:
                key = (course, sec['section'])
                if sec_counts[key] >= sec_cap[key]:
                    continue
                slot = (sec['semester'], sec['block'])
                if slot in timetable:
                    continue
                ok = True
                for pre in seq_prereq.get(course, []):
                    if pre in placed_set:
                        pre_sem = None
                        for (sem, blk), c in timetable.items():
                            if c == pre:
                                pre_sem = sem
                                break
                        if pre_sem is not None and pre_sem >= sec['semester']:
                            ok = False
                            break
                if not ok:
                    continue
                if best_sec is None or sec_counts[key] < best_enroll:
                    best_sec = sec
                    best_enroll = sec_counts[key]
            if best_sec is not None:
                key = (course, best_sec['section'])
                slot = (best_sec['semester'], best_sec['block'])
                timetable[slot] = course
                placed_list.append(course)
                placed_set.add(course)
                sec_counts[key] += 1

        for alt in alts:
            if alt in placed_set or alt not in master or not master[alt]:
                continue
            for sec in master[alt]:
                key = (alt, sec['section'])
                if sec_counts[key] >= sec_cap[key]:
                    continue
                slot = (sec['semester'], sec['block'])
                if slot not in timetable:
                    timetable[slot] = alt
                    placed_list.append(alt)
                    placed_set.add(alt)
                    sec_counts[key] += 1
                    break

        unplaced = [r for r in reqs if r not in placed_set]
        results.append({
            'id': student['id'],
            'grade': student['grade'],
            'requests': reqs,
            'alternates': alts,
            'timetable': timetable,
            'placed': placed_list,
            'unplaced': unplaced,
            'conflicts': 0
        })

    return results, sec_counts

def verify_blocking(master, blocking_groups):
    ok, total = 0, 0
    for grp in blocking_groups:
        valid = [c for c in grp if c in master]
        if len(valid) < 2: continue
        max_sec = min(len(master[c]) for c in valid)
        for i in range(max_sec):
            total += 1
            slots = set()
            for c in valid:
                secs = sorted(master[c], key=lambda s: s['section'])
                if i < len(secs) and secs[i]['type'] != 'OO':
                    slots.add((secs[i]['semester'], secs[i]['block']))
            if len(slots) <= 1: ok += 1
    pct = (ok / total * 100) if total else 100.0
    return pct, ok, total

def compute_metrics(sts, sec_counts, master, courses, rooms_dict, blocking_groups):
    gpool = masterTimeTableMaker.general_pool(rooms_dict)
    total_req = total_placed = full8 = s7plus = s8any = 0
    for st in sts:
        nreq = len(st['requests'])
        nplaced = sum(1 for c in st['placed'] if c in st['requests'])
        total_req += nreq
        total_placed += nplaced
        if nplaced == nreq: full8 += 1
        if nplaced >= 7: s7plus += 1
        if len(st['placed']) >= 8: s8any += 1
    n = len(sts)
    pct_placed = total_placed / total_req * 100 if total_req else 0
    pct_full = full8 / n * 100 if n else 0
    pct_7plus = s7plus / n * 100 if n else 0
    pct_8any = s8any / n * 100 if n else 0

    # Count room conflicts and invalid assignments
    room_conflicts = 0
    invalid_rooms = 0
    slot_room = defaultdict(set)
    for course, secs in master.items():
        for sec in secs:
            if sec['room'] is None or sec['type'] == 'OO':
                continue
            key = (sec['semester'], sec['block'], sec['room'])
            if slot_room[key]:
                room_conflicts += 1
            slot_room[key].add(course)
            allowed = masterTimeTableMaker.get_allowed_rooms(course, rooms_dict, gpool)
            if allowed and sec['room'] not in allowed:
                invalid_rooms += 1
                # Optionally print details
                # print(f"INVALID: {course} sec {sec['section']} in Sem{sec['semester']} Blk{sec['block']} room {sec['room']}")

    sec_total = len(sec_counts)
    full_sec = sum(1 for (c,_), cnt in sec_counts.items() if cnt >= masterTimeTableMaker.course_max_capacity(c))
    under_half = sum(1 for (c,_), cnt in sec_counts.items() if 0 < cnt < masterTimeTableMaker.course_max_capacity(c) * 0.5)
    empty_sec = sum(1 for cnt in sec_counts.values() if cnt == 0)
    overfilled = sum(1 for (c,_), cnt in sec_counts.items() if cnt > masterTimeTableMaker.course_max_capacity(c))

    blk_counts = defaultdict(int)
    for course, secs in master.items():
        for sec in secs:
            if sec['type'] != 'OO':
                blk_counts[(sec['semester'], sec['block'])] += 1
    avg = sum(blk_counts.values()) / len(blk_counts) if blk_counts else 0
    balanced = sum(1 for cnt in blk_counts.values() if abs(cnt - avg) <= 2)

    blk_pct, blk_ok, blk_tot = verify_blocking(master, blocking_groups)

    score = total_placed * 10 + full8 * 50
    score -= room_conflicts * 1000 + 0 * 1000
    score -= invalid_rooms * 500 + overfilled * 1000
    score += balanced + blk_ok * 20
    score = max(0, score)

    sec_enroll = [(c, sec, cnt, masterTimeTableMaker.course_max_capacity(c))
                  for (c, sec), cnt in sorted(sec_counts.items())]

    return {
        'total_requests': total_req, 'total_placed': total_placed,
        'pct_requests_placed': round(pct_placed, 1),
        'students_full_8_of_8': full8, 'pct_full_8_of_8': round(pct_full, 1),
        'students_7_plus': s7plus, 'pct_7_plus': round(pct_7plus, 1),
        'students_8_any': s8any, 'pct_8_any': round(pct_8any, 1),
        'student_conflicts': 0,
        'unassigned_requests': total_req - total_placed,
        'total_sections': sec_total, 'full_sections': full_sec,
        'sections_under_half': under_half, 'empty_sections': empty_sec,
        'room_conflicts': room_conflicts, 'invalid_room_assignments': invalid_rooms,
        'overfilled_classes': overfilled, 'balanced_sections': balanced,
        'block_distribution': dict(blk_counts),
        'blocking_rules_pct': round(blk_pct, 1),
        'blocking_rules_satisfied': blk_ok, 'blocking_rules_total': blk_tot,
        'optimization_score': score, 'section_enrollments': sec_enroll,
    }

def print_metrics(m):
    W = 72
    def row(lbl, val, w=44): print(f"  {lbl:<{w}} {val}")
    print("="*W)
    print("  MILESTONE 2 METRICS REPORT")
    print("="*W)
    print("\n── STUDENT PLACEMENT ──────────────────────────────────────────────")
    row("Total course requests:", m['total_requests'])
    row("Total requests placed:", m['total_placed'])
    row("% requests placed:", f"{m['pct_requests_placed']}%")
    row("Students with 8/8 requested:", f"{m['students_full_8_of_8']}  ({m['pct_full_8_of_8']}%)")
    row("Students with 7–8/8 requested:", f"{m['students_7_plus']}  ({m['pct_7_plus']}%)")
    row("Students with 8 courses total:", f"{m['students_8_any']}  ({m['pct_8_any']}%)")
    row("Student timetable conflicts:", m['student_conflicts'])
    row("Unassigned course requests:", m['unassigned_requests'])
    print("\n── ENROLLMENT ──────────────────────────────────────────────────────")
    row("Total sections scheduled:", m['total_sections'])
    row("Full sections:", m['full_sections'])
    row("Sections under 50% enrollment:", m['sections_under_half'])
    row("Empty sections (0 students):", m['empty_sections'])
    row("Overfilled sections:", m['overfilled_classes'])
    print("\n── TIMETABLE QUALITY ───────────────────────────────────────────────")
    row("Room conflicts:", m['room_conflicts'])
    row("Invalid room assignments:", m['invalid_room_assignments'])
    row("Blocking rules satisfied:", f"{m['blocking_rules_satisfied']}/{m['blocking_rules_total']}  ({m['blocking_rules_pct']}%)")
    row("Balanced blocks (±2 of avg):", m['balanced_sections'])
    row("Optimization score:", m['optimization_score'])
    print("\n── BLOCK DISTRIBUTION ──────────────────────────────────────────────")
    print(f"  {'Slot':<14} {'Sections':>8}  {'Bar'}")
    for (sem, blk), cnt in sorted(m['block_distribution'].items()):
        bar = '█' * (cnt // 3)
        print(f"  Sem{sem} Block {blk}   {cnt:>5}  {bar}")
    print("="*W)

def print_section_enrollments(sec_enroll, course_names):
    W = 72
    print("\n" + "="*W)
    print("  SECTION ENROLLMENTS")
    print("="*W)
    print(f"  {'Course':<14} {'Name':<26} {'§':>3}  {'Enrolled':>8}  {'Cap':>4}  {'Fill':>6}")
    print("  "+"-"*64)
    for course, sec, cnt, cap in sec_enroll:
        pct = cnt / cap * 100 if cap else 0
        name = course_names.get(course, '')[:25]
        flag = ' ⚠' if cnt < cap * 0.5 and cnt > 0 else ('  ✓' if cnt >= cap * 0.9 else '')
        print(f"  {course:<14} {name:<26} {sec:>3}  {cnt:>8}  {cap:>4}  {pct:>5.1f}%{flag}")
    print("="*W)

def export_student_csv(master, sts, course_names, id_to_num, fname='student_timetables.csv'):
    rows = []
    for st in sts:
        for (sem, blk), course in st['timetable'].items():
            room = 'N/A'
            for sec in master.get(course, []):
                if sec['semester'] == sem and sec['block'] == blk and sec['section'] is not None:
                    if sec['room'] is not None:
                        room = id_to_num.get(sec['room'], 'N/A')
                    break
            rows.append({'StudentID': st['id'], 'Grade': st['grade'], 'Semester': sem, 'Block': blk,
                         'Course': course_names.get(course, course), 'Room': room,
                         'Status': 'placed' if course in st['requests'] else 'alternate'})
        for course in st['unplaced']:
            rows.append({'StudentID': st['id'], 'Grade': st['grade'], 'Semester': 'UA', 'Block': 'UA',
                         'Course': course_names.get(course, course), 'Room': '', 'Status': 'unplaced'})
    with open(fname, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['StudentID','Grade','Semester','Block','Course','Room','Status'])
        w.writeheader()
        w.writerows(rows)
    print(f"  → {fname}")

def export_master_csv_crosstab(master, course_names, id_to_num, fname='master_timetable.csv'):
    blocks_order = ['A', 'B', 'C', 'D']
    sems = [1, 2]
    slot_lists = {}
    for sem in sems:
        for blk in blocks_order:
            slot_lists[(sem, blk)] = []

    for course, secs in master.items():
        for sec in secs:
            if sec['type'] == 'OO':
                continue
            sem = sec['semester']
            blk = sec['block']
            room_display = id_to_num.get(sec['room'], 'N/A') if sec['room'] is not None else 'N/A'
            name = course_names.get(course, course)
            entry = f"{name} (Sec {sec['section']}) [{room_display}]"
            slot_lists[(sem, blk)].append(entry)

    max_rows = max(len(slot_lists[(sem, blk)]) for sem in sems for blk in blocks_order)

    rows = []
    # Semester headers
    sem1_header = ['Semester 1', '', '', '', 'Semester 2', '', '', '']
    rows.append(sem1_header)
    # Block headers
    block_headers = []
    for _ in sems:
        for blk in blocks_order:
            block_headers.append(f"Block {blk}")
    rows.append(block_headers)
    # Data rows
    for i in range(max_rows):
        data_row = []
        for sem in sems:
            for blk in blocks_order:
                lst = slot_lists[(sem, blk)]
                if i < len(lst):
                    data_row.append(lst[i])
                else:
                    data_row.append('')
        rows.append(data_row)

    with open(fname, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerows(rows)
    print(f"  → {fname} (crosstab layout)")

def main():
    print("\n" + "="*72)
    print("  SCHOOL TIMETABLING — MILESTONE 2 (FINAL)")
    print("="*72 + "\n")

    master = masterTimeTableMaker.generate_timetable()
    courses = masterTimeTableMaker.load_courses()
    students = masterTimeTableMaker.load_students()
    sequencing = masterTimeTableMaker.load_sequencing()
    blocking = masterTimeTableMaker.load_blocking()
    rooms_dict, id_to_num = masterTimeTableMaker.load_rooms()
    course_names = {}
    path_names = "data/CourseNameTable.csv"
    if os.path.exists(path_names):
        with open(path_names, encoding='utf-8') as f:
            for row in csv.reader(f):
                if len(row) >= 2:
                    course_names[row[0].strip()] = row[1].strip()

    print("\nVerifying blocking rules...")
    pct, ok, tot = verify_blocking(master, blocking)
    print(f"  ✓ {ok}/{tot} rules satisfied ({pct:.1f}%)\n")

    print("Assigning students to sections...")
    sts, sec_counts = assign_students(students, courses, master, sequencing)
    print(f"  ✓ {len(sts)} students processed\n")

    print("Computing metrics...")
    metrics = compute_metrics(sts, sec_counts, master, courses, rooms_dict, blocking)
    print_metrics(metrics)
    print_section_enrollments(metrics['section_enrollments'], course_names)

    print("\nExporting CSV files...")
    export_master_csv_crosstab(master, course_names, id_to_num, 'master_timetable.csv')
    export_student_csv(master, sts, course_names, id_to_num)

    # BONUS: exactly 8 primary requests, all placed, all 8 blocks filled, no alternates in blocks
    full_sts = [st for st in sts
                if len(st['requests']) == 8
                and all(r in st['placed'] for r in st['requests'])
                and len(st['timetable']) == 8
                and all(c in st['requests'] for c in st['timetable'].values())]

    print(f"\n{'='*72}")
    print("  BONUS: 3 STUDENTS WITH ALL 8 REQUESTED COURSES PLACED (no alternates)")
    print("="*72)
    if len(full_sts) >= 3:
        for st in random.sample(full_sts, 3):
            print(f"\n  Student {st['id']}  (Grade {st['grade']})")
            for sem in (1,2):
                for blk in ['A','B','C','D']:
                    c = st['timetable'].get((sem, blk))
                    if c:
                        name = course_names.get(c, c)
                        tag = ' ★' if c in st['requests'] else ''
                        print(f"    Sem{sem}-{blk}: {name}{tag}")
        # OO courses (if any – but with len(timetable)==8, there should be none)
        oo_courses = [c for c in st['placed'] if c not in [v for v in st['timetable'].values()]]
        if oo_courses:
            for c in oo_courses:
                name = course_names.get(c, c)
                tag = ' ★' if c in st['requests'] else ''
                print(f"    Out of Timetable: {name}{tag}")
    else:
        print(f"  Only {len(full_sts)} fully-scheduled students found.")
    print("\nDone.\n")

if __name__ == '__main__':
    main()