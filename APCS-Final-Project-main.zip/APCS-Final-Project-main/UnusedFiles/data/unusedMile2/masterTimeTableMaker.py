import csv, os
from collections import defaultdict
from ortools.sat.python import cp_model

BLOCKS = ['A', 'B', 'C', 'D']
SEMESTERS = [1, 2]
DATA_DIR = 'data'
DEFAULT_MAX_CAPACITY = 30
LAB_MAX_CAPACITY = 24
LAB_COURSE_PREFIXES = ('MATPH','MCH','MPH','MEVSC','MWWK',
                       'MTAUT','MTEAD','MTROB','MMACS','MCMPR','MTDRF')

SPECIALTY_ONLY_ROOMS = {500,501,502,503,504,514,515,541,547,548}

def load_rooms():
    rooms = {}
    id_to_num = {}
    with open(f"{DATA_DIR}/roomsClean.csv", encoding='utf-8-sig') as f:
        for row in csv.reader(f):
            if not row or row[0].strip() in ('','ID'): continue
            try:
                rid = int(row[0].strip())
                department = row[1].strip()
                room_num = row[2].strip()
                rooms[rid] = department
                id_to_num[rid] = room_num
            except ValueError:
                continue
    return rooms, id_to_num

def general_pool(rooms_dict):
    return sorted(r for r in rooms_dict if r not in SPECIALTY_ONLY_ROOMS)

def get_allowed_rooms(code, rooms_dict, gpool=None, id_to_num=None):
    if code.startswith(('Y','X','PBB')): return []
    # Specialty rooms
    if code.startswith(('MWWK','MADW')): return [500]
    if code.startswith(('MTAUT','MTEAD')): return [501]
    if code.startswith(('MTPOW',)): return [502]
    if code.startswith(('MADER','MTROB','MTEAR','MTEXP')): return [503]
    if code.startswith(('MTDRF','MADD','MADGE')): return [504]
    if code.startswith(('MDRM','MDR--')): return [541]
    if code.startswith(('MDCF','MDNC','MDN')): return [548]
    if code.startswith(('MIMG','MIMC','MMUC','MMUJ','MMUO','MCMCC','MMUCC','XC','MIMCB','MIMJB','MMUCB','MMUJB','MMUOR','XBA','XC','XLDCB')): return [514]
    if code.startswith(('MPHE','MPHED','MACLV')): return [515,547]
    if code.startswith(('MMACS','MCMPR','MWBDV')): return [519,520,511]
    if code.startswith(('MFOOD',)): return [521]
    
    if gpool is None: gpool = general_pool(rooms_dict)
    math_science_prefixes = ('MATPH','MCH','MPH','MEVSC','MCALC','MPREC','MFMP','MFOM','MMA','MWPM',
                             'ACAL','ASTA','APHM','MSC','MCH--','MPH--')
    if any(code.startswith(p) for p in math_science_prefixes):
        if id_to_num is not None:
            filtered = [r for r in gpool if not id_to_num.get(r, '').startswith('A-')]
            labs = [525,528,529,533,534,535,536]
            return list(set(labs + filtered))
        else:
            return gpool
    return gpool

def load_courses():
    courses = {}
    with open(f"{DATA_DIR}/sections.csv") as f:
        for row in csv.reader(f):
            if not row: continue
            code = row[0].strip()
            n_sec = int(row[1].strip())
            sched = row[2].strip().upper() if len(row)>2 and row[2].strip() else 'ED'
            if code.startswith(('Y','X','PBB')):
                sched = 'OO'
            room_type = row[3].strip() if len(row)>3 and row[3].strip() else 'Classroom'
            courses[code] = {'sections': n_sec, 'type': sched, 'room_type': room_type}
    return courses

def load_sequencing():
    pairs = []
    path = f"{DATA_DIR}/sequencing.csv"
    if not os.path.exists(path): return pairs
    with open(path) as f:
        for line in f:
            codes = [c.strip().strip('"') for c in line.strip().strip('"').split(',') if c.strip().strip('"')]
            for i in range(len(codes)-1):
                pairs.append((codes[i], codes[i+1]))
    return pairs

def load_blocking():
    groups = []
    path = f"{DATA_DIR}/blocking.csv"
    if not os.path.exists(path): return groups
    with open(path) as f:
        for line in f:
            codes = [c.strip() for c in line.strip().split(',') if c.strip() and c.strip().lower() not in ('s','n','c')]
            if len(codes)>1: groups.append(codes)
    return groups

def course_max_capacity(code):
    return LAB_MAX_CAPACITY if any(code.startswith(p) for p in LAB_COURSE_PREFIXES) else DEFAULT_MAX_CAPACITY

def load_students():
    students, current = [], None
    with open(f"{DATA_DIR}/cleanedstudentrequests.csv", encoding='utf-8-sig') as f:
        for row in csv.reader(f):
            if not row: continue
            col0 = row[0].strip()
            if col0 == 'ID':
                if current: students.append(current)
                sid = int(row[1].strip())
                grade = int(row[3].strip()) if len(row)>3 and row[3].strip().isdigit() else 0
                current = {'id':sid,'grade':grade,'requests':[],'alternates':[]}
            elif col0 in ('Course','') or not col0:
                continue
            elif current is not None:
                is_alt = len(row)>10 and row[10].strip().upper()=='Y'
                if is_alt: current['alternates'].append(col0)
                else:       current['requests'].append(col0)
    if current: students.append(current)
    return students

def adjust_sections_by_demand(courses, students):
    demand = defaultdict(int)
    for s in students:
        for req in s['requests']:
            demand[req] += 1
    adjusted = {}
    for code, info in courses.items():
        cap = course_max_capacity(code)
        orig = info['sections']
        d = demand.get(code, 0)
        if cap > 0:
            if d < cap // 2:
                max_sec = 0
            else:
                max_sec = (d - cap//2) // cap + 1
        else:
            max_sec = 0
        new_sec = min(orig, max_sec)
        if new_sec > 0 or info['type'] == 'OO':
            adjusted[code] = {'sections': new_sec, 'type': info['type'], 'room_type': info['room_type']}
        else:
            print(f"  ✗ Course {code} has {d} requests, capacity {cap} → would be under 50%, removing all sections.")
    return adjusted

def make_sessions(non_oo, blocking_groups):
    all_secs = [(c,i) for c,info in non_oo.items() for i in range(info['sections'])]
    parent = {s:s for s in all_secs}
    def find(s):
        while parent[s]!=s:
            parent[s]=parent[parent[s]]; s=parent[s]
        return s
    def union(a,b):
        ra,rb = find(a),find(b)
        if ra!=rb: parent[ra]=rb
    for grp in blocking_groups:
        valid = [c for c in grp if c in non_oo]
        if len(valid)<2: continue
        mn = min(non_oo[c]['sections'] for c in valid)
        for i in range(mn):
            for c in valid[1:]:
                union((valid[0],i),(c,i))
    sm = defaultdict(list)
    for s in all_secs: sm[find(s)].append(s)
    return list(sm.values())

def build_master_timetable(courses, blocking_groups, rooms_dict, id_to_num):
    non_oo = {c:i for c,i in courses.items() if i['type']!='OO' and i['sections']>0}
    oo_courses = {c:i for c,i in courses.items() if i['type']=='OO' and i['sections']>0}
    gpool = general_pool(rooms_dict)
    sessions = make_sessions(non_oo, blocking_groups)
    n = len(sessions)
    nb = len(BLOCKS)
    print(f"  Sessions: {n}  |  General pool: {len(gpool)} rooms")

    # CP‑SAT semester assignment
    model = cp_model.CpModel()
    sem_vars = [model.NewIntVar(1,2,f'sem_{i}') for i in range(n)]
    sequencing = load_sequencing()
    sec_to_idx = {}
    for idx, sess in enumerate(sessions):
        for sec in sess:
            sec_to_idx[sec] = idx
    for pre, post in sequencing:
        if pre not in non_oo or post not in non_oo:
            continue
        for i in range(non_oo[pre]['sections']):
            for j in range(non_oo[post]['sections']):
                ip = sec_to_idx.get((pre,i))
                iq = sec_to_idx.get((post,j))
                if ip is not None and iq is not None:
                    model.Add(sem_vars[ip] < sem_vars[iq])

    weights = [len(s) for s in sessions]
    total_w = sum(weights)
    target = total_w // 2
    bools = [model.NewBoolVar(f'b_{i}') for i in range(n)]
    for i in range(n):
        model.Add(sem_vars[i]==1).OnlyEnforceIf(bools[i])
        model.Add(sem_vars[i]==2).OnlyEnforceIf(bools[i].Not())
    s1sum = model.NewIntVar(0,total_w,'s1sum')
    model.Add(s1sum == sum(bools[i]*weights[i] for i in range(n)))
    diff = model.NewIntVar(-total_w,total_w,'diff')
    abs_diff = model.NewIntVar(0,total_w,'abs_diff')
    model.Add(diff == s1sum - target)
    model.AddAbsEquality(abs_diff, diff)
    model.Minimize(abs_diff)

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 60.0
    solver.parameters.num_search_workers = 4
    status = solver.Solve(model)
    if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        semesters = [solver.Value(sem_vars[i]) for i in range(n)]
        print("  CP‑SAT assigned semesters.")
    else:
        print("  CP‑SAT failed – using fallback semester assignment (based on index).")
        semesters = [1 if i < n//2 else 2 for i in range(n)]

    # Round‑robin block assignment
    sem1_indices = [i for i in range(n) if semesters[i]==1]
    sem2_indices = [i for i in range(n) if semesters[i]==2]
    blocks_cycle = list(range(nb))
    sem_blk = [None]*n
    for i, idx in enumerate(sem1_indices):
        sem_blk[idx] = (1, blocks_cycle[i % nb])
    for i, idx in enumerate(sem2_indices):
        sem_blk[idx] = (2, blocks_cycle[i % nb])

    # Precompute allowed rooms per session (intersection)
    session_allowed = []
    for idx, sess in enumerate(sessions):
        allowed_set = None
        for course, _ in sess:
            allowed = set(get_allowed_rooms(course, rooms_dict, gpool, id_to_num))
            if not allowed:
                allowed = set(gpool)
            if allowed_set is None:
                allowed_set = allowed
            else:
                allowed_set &= allowed
        if not allowed_set:
            allowed_set = set(gpool)
        session_allowed.append(allowed_set)

    # Greedy room assignment per slot
    slot_sessions = defaultdict(list)
    for idx, (sem, blk) in enumerate(sem_blk):
        slot_sessions[(sem, blk)].append(idx)
    room_assignment = {}
    for (sem, blk), idx_list in slot_sessions.items():
        session_list = sorted([(i, session_allowed[i]) for i in idx_list], key=lambda x: len(x[1]))
        used_rooms = set()
        for i, allowed_set in session_list:
            sorted_allowed = sorted(allowed_set,
                                    key=lambda rid: (0 if id_to_num.get(rid, '').startswith('A-') else 1,
                                                     id_to_num.get(rid, '9999')))
            chosen = None
            for r in sorted_allowed:
                # Ensure this room is allowed for every course in the session
                if all(r in get_allowed_rooms(course, rooms_dict, gpool, id_to_num) for (course,_) in sessions[i]):
                    if r not in used_rooms:
                        chosen = r
                        break
            if chosen is None:
                chosen = sorted_allowed[0]   # fallback (should rarely happen)
            used_rooms.add(chosen)
            for (course, sec_i) in sessions[i]:
                room_assignment[(course, sec_i)] = chosen

    # Build master timetable
    master = defaultdict(list)
    for idx, (sem, blk) in enumerate(sem_blk):
        for (course, sec_i) in sessions[idx]:
            entry = {
                'section': sec_i+1,
                'semester': sem,
                'block': BLOCKS[blk],
                'room': room_assignment.get((course, sec_i)),
                'type': non_oo[course]['type'],
                'pattern': 'Every Day' if non_oo[course]['type']=='ED' else 'MWF (Day A/B)'
            }
            master[course].append(entry)

    for code, info in oo_courses.items():
        for i in range(info['sections']):
            master[code].append({
                'section': i+1,
                'semester': 1,
                'block': 'OO',
                'room': None,
                'type': 'OO',
                'pattern': 'Out of Timetable'
            })

    for code in master:
        master[code].sort(key=lambda x: (x['semester'], x['block'], x['section']))

    # --- POST‑PROCESS: fix any invalid room assignments ---
    gpool_set = set(gpool)
    for course, secs in master.items():
        for sec in secs:
            if sec['type'] == 'OO' or sec['room'] is None:
                continue
            allowed = set(get_allowed_rooms(course, rooms_dict, gpool, id_to_num))
            if not allowed:
                allowed = gpool_set
            if sec['room'] not in allowed:
                # Try to reassign to a valid room in the same (semester, block) slot
                same_slot = [(c, s) for c, sl in master.items() for s in sl
                             if s['type'] != 'OO' and s['semester'] == sec['semester'] and s['block'] == sec['block']]
                # Collect currently used rooms in this slot
                used_in_slot = {s['room'] for (c, s) in same_slot}
                # Find a room that is allowed for this course and not used in slot
                new_room = None
                for r in sorted(allowed, key=lambda rid: (0 if id_to_num.get(rid, '').startswith('A-') else 1,
                                                          id_to_num.get(rid, '9999'))):
                    if r not in used_in_slot:
                        new_room = r
                        break
                if new_room is not None:
                    sec['room'] = new_room
                else:
                    # If no free room, force the first allowed room (may cause conflict but better than invalid)
                    sec['room'] = min(allowed, key=lambda rid: (0 if id_to_num.get(rid, '').startswith('A-') else 1,
                                                                 id_to_num.get(rid, '9999')))
    return dict(master)

def export_master_csv_vertical(master, course_names, id_to_num, fname='master_timetable.csv'):
    rows = [['Course Code','Course Name','Section','Semester','Block','Room','Type','Pattern']]
    for code in sorted(master):
        for sec in master[code]:
            room_display = id_to_num.get(sec['room'], 'N/A') if sec['room'] is not None else 'N/A'
            rows.append([code, course_names.get(code,''), sec['section'],
                         sec['semester'], sec['block'], room_display,
                         sec['type'], sec['pattern']])
    with open(fname,'w',newline='') as f:
        csv.writer(f).writerows(rows)
    print(f"  → {fname}")

def generate_timetable():
    print("Loading data...")
    courses_orig = load_courses()
    students = load_students()
    rooms_dict, id_to_num = load_rooms()
    blocking = load_blocking()

    courses = adjust_sections_by_demand(courses_orig, students)

    course_names = {}
    path_names = f"{DATA_DIR}/CourseNameTable.csv"
    if os.path.exists(path_names):
        with open(path_names, encoding='utf-8') as f:
            for row in csv.reader(f):
                if len(row)>=2: course_names[row[0].strip()] = row[1].strip()

    print(f"  Courses after demand adjustment: {len(courses)}  |  Students: {len(students)}  |  Blocking groups: {len(blocking)}")
    print("Building master timetable...")
    master = build_master_timetable(courses, blocking, rooms_dict, id_to_num)
    tt_sec = sum(1 for v in master.values() for s in v if s['type']!='OO')
    print(f"  ✓ {len(master)} courses, {sum(len(v) for v in master.values())} sections ({tt_sec} in‑timetable)")
    return master

if __name__ == '__main__':
    generate_timetable()