"""
School Timetabling Problem — Milestone 2 (Final)
Uses masterTimeTableMaker for timetable generation (flexible rooms, half‑fill constraint)
then applies student assignment and metrics.
"""
import csv, random, os
from collections import defaultdict
import masterTimeTableMaker

def assign_students(students, courses, master, seq_pairs):
    sec_cap = {}
    for course, secs in master.items():
        cap = masterTimeTableMaker.course_max_capacity(course)
        for sec in secs:
            sec_cap[(course, sec['section'])] = cap

    sec_counts = defaultdict(int)
    results = []

    """
    def calculate_student_difficulty(student):
        score = 0
        for req in student['requests']:
            # Ignore Out of Timetable (OO) courses as they are always placeable
            if any(s['type'] == 'OO' for s in master.get(req, [])):
                continue
            
            available_sections = len(master.get(req, []))
            if available_sections > 0:
                # Add a higher penalty for courses with fewer sections (e.g., 1 section = 1.0 score, 5 sections = 0.2 score)
                score += 1.0 / available_sections 
            else:
                score += 10 # Massive penalty if a requested course has 0 sections
        return score

    sorted_students = sorted(students, key=calculate_student_difficulty, reverse=True)
    """

    seq_prereq = defaultdict(list)
    for pre, post in seq_pairs:
        seq_prereq[post].append(pre)

    # for student in sorted(students, key=lambda s: len(s['requests'])):
    # for student in sorted(students, key=lambda s: (int(s['grade']), len(s['requests'])), reverse=True):
    #for student in sorted(students, key=lambda s: (
    #    sum(1 for r in s['requests'] if r in master and len(master[r]) <= 2), 
    #    int(s['grade']), 
    #    len(s['requests'])
    #), reverse=True):
    #
    #

    for student in sorted(students, key=lambda s: (int(s['grade']), len(s['requests'])), reverse=True):
        reqs = student['requests']
        alts = student.get('alternates', [])

        oo_placed = [r for r in reqs+alts
                     if r in master and master[r] and master[r][0]['type'] == 'OO']
        normal = [r for r in reqs if r not in oo_placed and r in master and master[r]]
        normal.sort(key=lambda r: len(master.get(r, [])))

        timetable = {}
        placed_list = list(oo_placed)
        placed_set = set(oo_placed)

        for course in normal:
            best_sec = None
            best_enroll = None
            for sec in master[course]:
                key = (course, sec['section'])
                cap = sec_cap.get(key, 0)
                slot = (sec['semester'], sec['block'])
                if sec_counts[key] >= sec_cap[key]:
                    continue
                slot = (sec['semester'], sec['block'])
                if slot in timetable:
                    continue
                ok = True
                for pre in seq_prereq.get(course, []):
                    if pre in placed_set:
                        pre_sem = None
                        for (sem, blk), c in timetable.items():
                            if c == pre:
                                pre_sem = sem
                                break
                        if pre_sem is not None and pre_sem >= sec['semester']:
                            ok = False
                            break
                if not ok:
                    continue
                if best_sec is None or sec_counts[key] < best_enroll:
                    best_sec = sec
                    best_enroll = sec_counts[key]
            if best_sec is not None:
                key = (course, best_sec['section'])
                slot = (best_sec['semester'], best_sec['block'])
                timetable[slot] = course
                placed_list.append(course)
                placed_set.add(course)
                sec_counts[key] += 1

        for alt in alts:
            if alt in placed_set or alt not in master or not master[alt]:
                continue
            for sec in master[alt]:
                key = (alt, sec['section'])
                if sec_counts[key] >= sec_cap[key]:
                    continue
                slot = (sec['semester'], sec['block'])
                if slot not in timetable:
                    timetable[slot] = alt
                    placed_list.append(alt)
                    placed_set.add(alt)
                    sec_counts[key] += 1
                    break

        unplaced = [r for r in reqs if r not in placed_set]
        results.append({
            'id': student['id'],
            'grade': student['grade'],
            'requests': reqs,
            'alternates': alts,
            'timetable': timetable,
            'placed': placed_list,
            'unplaced': unplaced,
            'conflicts': 0
        })

    return results, sec_counts

def verify_blocking(master, blocking_groups):
    ok, total = 0, 0
    for grp in blocking_groups:
        valid = [c for c in grp if c in master]
        if len(valid) < 2: continue
        max_sec = min(len(master[c]) for c in valid)
        for i in range(max_sec):
            total += 1
            slots = set()
            for c in valid:
                secs = sorted(master[c], key=lambda s: s['section'])
                if i < len(secs) and secs[i]['type'] != 'OO':
                    slots.add((secs[i]['semester'], secs[i]['block']))
            if len(slots) <= 1: ok += 1
    pct = (ok / total * 100) if total else 100.0
    return pct, ok, total

def compute_metrics(sts, sec_counts, master, courses, rooms_dict, blocking_groups):
    gpool = masterTimeTableMaker.general_pool(rooms_dict)
    total_req = total_placed = full8 = s7plus = s8any = 0
    for st in sts:
        nreq = len(st['requests'])
        nplaced = sum(1 for c in st['placed'] if c in st['requests'])
        total_req += nreq
        total_placed += nplaced
        if nplaced == nreq: full8 += 1
        if nplaced >= 7: s7plus += 1
        if len(st['placed']) >= 8: s8any += 1
    n = len(sts)
    pct_placed = total_placed / total_req * 100 if total_req else 0
    pct_full = full8 / n * 100 if n else 0
    pct_7plus = s7plus / n * 100 if n else 0
    pct_8any = s8any / n * 100 if n else 0

    blocked_pairs = set()
    for grp in blocking_groups:
        for i in range(len(grp)):
            for j in range(i+1, len(grp)):
                blocked_pairs.add((grp[i], grp[j]))
                blocked_pairs.add((grp[j], grp[i]))

    # Count room conflicts and invalid assignments
    room_conflicts = 0
    invalid_rooms = 0 
    slot_room = defaultdict(set)
    for course, secs in master.items():
        for sec in secs:
            if sec['room'] is None or sec['type'] == 'OO':
                continue
            key = (sec['semester'], sec['block'], sec['room'])
            for existing_course in slot_room[key]:
                # Only flag if NOT a legitimate blocking pair
                if (course, existing_course) not in blocked_pairs:
                    room_conflicts += 1
            slot_room[key].add(course)
            allowed = masterTimeTableMaker.get_allowed_rooms(course, rooms_dict, gpool)
            if allowed and sec['room'] not in allowed:
                invalid_rooms += 1
                # Optionally print details
                # print(f"INVALID: {course} sec {sec['section']} in Sem{sec['semester']} Blk{sec['block']} room {sec['room']}")

    sec_total = len(sec_counts)
    full_sec = sum(1 for (c,_), cnt in sec_counts.items() if cnt >= masterTimeTableMaker.course_max_capacity(c))
    under_half = sum(1 for (c,_), cnt in sec_counts.items() if 0 < cnt < masterTimeTableMaker.course_max_capacity(c) * 0.5)
    empty_sec = sum(1 for cnt in sec_counts.values() if cnt == 0)
    overfilled = sum(1 for (c,_), cnt in sec_counts.items() if cnt > masterTimeTableMaker.course_max_capacity(c))

    blk_counts = defaultdict(int)
    for course, secs in master.items():
        for sec in secs:
            if sec['type'] != 'OO':
                blk_counts[(sec['semester'], sec['block'])] += 1
    avg = sum(blk_counts.values()) / len(blk_counts) if blk_counts else 0
    balanced = sum(1 for cnt in blk_counts.values() if abs(cnt - avg) <= 2)

    blk_pct, blk_ok, blk_tot = verify_blocking(master, blocking_groups)

    score = total_placed * 10 + full8 * 50
    score -= room_conflicts * 1000 + 0 * 1000
    score -= invalid_rooms * 500 + overfilled * 1000
    score += balanced + blk_ok * 20
    score = max(0, score)

    sec_enroll = [(c, sec, cnt, masterTimeTableMaker.course_max_capacity(c))
                  for (c, sec), cnt in sorted(sec_counts.items())]

    return {
        'total_requests': total_req, 'total_placed': total_placed,
        'pct_requests_placed': round(pct_placed, 1),
        'students_full_8_of_8': full8, 'pct_full_8_of_8': round(pct_full, 1),
        'students_7_plus': s7plus, 'pct_7_plus': round(pct_7plus, 1),
        'students_8_any': s8any, 'pct_8_any': round(pct_8any, 1),
        'student_conflicts': 0,
        'unassigned_requests': total_req - total_placed,
        'total_sections': sec_total, 'full_sections': full_sec,
        'sections_under_half': under_half, 'empty_sections': empty_sec,
        'room_conflicts': room_conflicts, 'invalid_room_assignments': invalid_rooms,
        'overfilled_classes': overfilled, 'balanced_sections': balanced,
        'block_distribution': dict(blk_counts),
        'blocking_rules_pct': round(blk_pct, 1),
        'blocking_rules_satisfied': blk_ok, 'blocking_rules_total': blk_tot,
        'optimization_score': score, 'section_enrollments': sec_enroll,
    }

def print_metrics(m):
    W = 72
    def row(lbl, val, w=44): print(f"  {lbl:<{w}} {val}")
    print("="*W)
    print("  MILESTONE 2 METRICS REPORT")
    print("="*W)
    print("\n── STUDENT PLACEMENT ──────────────────────────────────────────────")
    row("Total course requests:", m['total_requests'])
    row("Total requests placed:", m['total_placed'])
    row("% requests placed:", f"{m['pct_requests_placed']}%")
    row("Students with 8/8 requested:", f"{m['students_full_8_of_8']}  ({m['pct_full_8_of_8']}%)")
    row("Students with 7–8/8 requested:", f"{m['students_7_plus']}  ({m['pct_7_plus']}%)")
    row("Students with 8 courses total:", f"{m['students_8_any']}  ({m['pct_8_any']}%)")
    row("Student timetable conflicts:", m['student_conflicts'])
    row("Unassigned course requests:", m['unassigned_requests'])
    print("\n── ENROLLMENT ──────────────────────────────────────────────────────")
    row("Total sections scheduled:", m['total_sections'])
    row("Full sections:", m['full_sections'])
    row("Sections under 50% enrollment:", m['sections_under_half'])
    row("Empty sections (0 students):", m['empty_sections'])
    row("Overfilled sections:", m['overfilled_classes'])
    print("\n── TIMETABLE QUALITY ───────────────────────────────────────────────")
    row("Room conflicts:", m['room_conflicts'])
    row("Invalid room assignments:", m['invalid_room_assignments'])
    row("Blocking rules satisfied:", f"{m['blocking_rules_satisfied']}/{m['blocking_rules_total']}  ({m['blocking_rules_pct']}%)")
    row("Balanced blocks (±2 of avg):", m['balanced_sections'])
    row("Optimization score:", m['optimization_score'])
    print("\n── BLOCK DISTRIBUTION ──────────────────────────────────────────────")
    print(f"  {'Slot':<14} {'Sections':>8}  {'Bar'}")
    for (sem, blk), cnt in sorted(m['block_distribution'].items()):
        bar = '█' * (cnt // 3)
        print(f"  Sem{sem} Block {blk}   {cnt:>5}  {bar}")
    print("="*W)

def print_section_enrollments(sec_enroll, course_names):
    W = 72
    print("\n" + "="*W)
    print("  SECTION ENROLLMENTS")
    print("="*W)
    print(f"  {'Course':<14} {'Name':<26} {'§':>3}  {'Enrolled':>8}  {'Cap':>4}  {'Fill':>6}")
    print("  "+"-"*64)
    for course, sec, cnt, cap in sec_enroll:
        pct = cnt / cap * 100 if cap else 0
        name = course_names.get(course, '')[:25]
        flag = ' ⚠' if cnt < cap * 0.5 and cnt > 0 else ('  ✓' if cnt >= cap * 0.9 else '')
        print(f"  {course:<14} {name:<26} {sec:>3}  {cnt:>8}  {cap:>4}  {pct:>5.1f}%{flag}")
    print("="*W)

def export_student_csv(master, sts, course_names, id_to_num, fname='student_timetables.csv'):
    rows = []
    for st in sts:
        for (sem, blk), course in st['timetable'].items():
            room = 'N/A'
            for sec in master.get(course, []):
                if sec['semester'] == sem and sec['block'] == blk and sec['section'] is not None:
                    if sec['room'] is not None:
                        room = id_to_num.get(sec['room'], 'N/A')
                    break
            rows.append({'StudentID': st['id'], 'Grade': st['grade'], 'Semester': sem, 'Block': blk,
                         'Course': course_names.get(course, course), 'Room': room,
                         'Status': 'placed' if course in st['requests'] else 'alternate'})
        for course in st['unplaced']:
            rows.append({'StudentID': st['id'], 'Grade': st['grade'], 'Semester': 'UA', 'Block': 'UA',
                         'Course': course_names.get(course, course), 'Room': '', 'Status': 'unplaced'})
    with open(fname, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['StudentID','Grade','Semester','Block','Course','Room','Status'])
        w.writeheader()
        w.writerows(rows)
    print(f"  → {fname}")

def export_master_csv_crosstab(master, sec_counts, course_names, id_to_num, fname='master_timetable.csv'):
    blocks_order = ['A', 'B', 'C', 'D']
    sems = [1, 2]

    slot_lists = {}
    for sem in sems:
        for blk in blocks_order:
            slot_lists[(sem, blk)] = []

    for course, secs in master.items():
        for sec in secs:
            if sec['type'] == 'OO':
                continue

            room_display = (
                id_to_num.get(sec['room'], 'N/A')
                if sec['room'] is not None else 'N/A'
            )

            enrolled = sec_counts.get((course, sec['section']), 0)

            slot_lists[(sec['semester'], sec['block'])].append({
                'Course': course_names.get(course, course),
                'Section': sec['section'],
                'Room': room_display,
                'Enrolled': enrolled,
            })

    max_rows = max(
        len(slot_lists[(sem, blk)])
        for sem in sems
        for blk in blocks_order
    )

    rows = []

    # Top header row
    header1 = []
    for sem in sems:
        for blk in blocks_order:
            header1.extend([f"Sem {sem} Block {blk}", "", "", ""])
    rows.append(header1)

    # Column header row
    header2 = []
    for sem in sems:
        for blk in blocks_order:
            header2.extend([
                "Course",
                "Sec",
                "Room",
                "Enrolled",
            ])
    rows.append(header2)

    # Data rows
    for i in range(max_rows):
        row = []

        for sem in sems:
            for blk in blocks_order:
                lst = slot_lists[(sem, blk)]

                if i < len(lst):
                    item = lst[i]
                    row.extend([
                        item['Course'],
                        item['Section'],
                        item['Room'],
                        item['Enrolled'],
                    ])
                else:
                    row.extend(["", "", "", ""])

        rows.append(row)

    with open(fname, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerows(rows)

    print(f"  → {fname}")

# ============================== REPAIR BASED SCHEDULING FUNCTIONS ==================================
def load_schedule_for_repair(filename="student_timetables.csv"):
    """
    Reads the CSV and reconstructs the student schedules.
    Returns a dictionary mapping student_id to their schedule data.
    """
    # Dictionary to hold the reconstructed schedules
    students_data = defaultdict(lambda: {'timetable': {}, 'unplaced': [], 'grade': None})
    
    with open(filename, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            student_id = int(row['StudentID'])
            course = row['Course']
            status = row['Status']
            
            students_data[student_id]['grade'] = row['Grade']
            
            if status == 'placed':
                # Convert Semester back to int, keep Block as string
                sem = int(row['Semester'])
                blk = row['Block']
                # Store the placed course in the specific time slot
                students_data[student_id]['timetable'][(sem, blk)] = course
            
            elif status == 'unplaced':
                # Add to the unplaced list
                students_data[student_id]['unplaced'].append(course)
                
    return students_data

def repair_schedules(students_data, master, section_counts):
    """
    Attempts to place unplaced courses into empty slots in a student's timetable.
    """
    repairs_made = 0
    
    # Pre-calculate capacities as done in mile2.py
    section_capacity = {}
    for course, secs in master.items():
        # Assuming DEFAULT_MAX_CAPACITY = 30 for simplicity here
        max_cap = 24 if any(course.startswith(p) for p in ['MATPH', 'MCH', 'MTAUT']) else 30
        for sec in secs:
            section_capacity[(course, sec['section'])] = max_cap

    # Iterate through every student who has unplaced courses
    for student_id, data in students_data.items():
        if not data['unplaced']:
            continue # Skip fully scheduled students
            
        still_unplaced = []
        
        for unplaced_course in data['unplaced']:
            placed_this_course = False
            
            # Check if the course exists in the master timetable
            if unplaced_course in master:
                # Look at every available section for this course
                for sec in master[unplaced_course]:
                    slot = (sec['semester'], sec['block'])
                    sec_key = (unplaced_course, sec['section'])
                    
                    # 1. Does the student have this slot free?
                    if slot not in data['timetable']:
                        # 2. Is there room in the class?
                        if section_counts[sec_key] < section_capacity[sec_key]:
                            
                            # Make the repair!
                            data['timetable'][slot] = unplaced_course
                            section_counts[sec_key] += 1
                            placed_this_course = True
                            repairs_made += 1
                            print(f"Repair: Assigned {unplaced_course} to Student {student_id} in Sem {slot[0]} Block {slot[1]}")
                            break # Stop looking for sections for this course
                            
            if not placed_this_course:
                still_unplaced.append(unplaced_course)
                
        # Update the student's unplaced list
        data['unplaced'] = still_unplaced
        
    print(f"\nTotal successful repairs made: {repairs_made}")
    return students_data, section_counts

def export_repaired_csv(students_data, filename='MileStone2Update/data/repaired_student_timetables.csv'):
    rows = []
    for student_id, data in students_data.items():
        # Write placed courses
        for (sem, blk), course in data['timetable'].items():
            rows.append({
                'StudentID': student_id,
                'Grade': data['grade'],
                'Semester': sem,
                'Block': blk,
                'Course': course,
                'Status': 'placed'
            })
        # Write remaining unplaced courses
        for course in data['unplaced']:
            rows.append({
                'StudentID': student_id,
                'Grade': data['grade'],
                'Semester': 'UA',
                'Block': 'UA',
                'Course': course,
                'Status': 'unplaced'
            })
            
    with open(filename, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['StudentID','Grade','Semester','Block','Course','Status'])
        w.writeheader()
        w.writerows(rows)
    print(f"Repaired timetables saved to '{filename}'")

def format_for_metrics(studentTT_dict):
    """
    Converts the loaded CSV dictionary back into the format expected by compute_metrics.
    """
    formatted_timetables = []
    
    # Iterate through both the integer key (student_id) and the list of course info
    for student_id, courses in studentTT_dict.items():
        # Rebuild the student's record
        student_record = {
            'id': student_id,
            'grade': courses[0][0], # Grade from the first course entry
            'requests': [],
            'timetable': {},
            'placed': [],
            'unplaced': []
        }
        
        for info in courses:
            course_name = info[1]
            semester = info[2]
            block = info[3]
            status = info[4]
            
            # Every course in the CSV was a requested course
            student_record['requests'].append(course_name)
            
            if status == 'placed':
                student_record['placed'].append(course_name)
                # Semester might need to be an int, block a string, depending on mile2.py
                student_record['timetable'][(int(semester), block)] = course_name
            elif status == 'unplaced':
                student_record['unplaced'].append(course_name)
                
        formatted_timetables.append(student_record)
        
    return formatted_timetables






# ========================== MAIN ==========================
def main():
    print("\n" + "="*72)
    print("  SCHOOL TIMETABLING — MILESTONE 3 (FINAL)")
    print("="*72 + "\n")

    master = masterTimeTableMaker.generate_timetable()
    courses = masterTimeTableMaker.load_courses()
    students = masterTimeTableMaker.load_students()
    sequencing = masterTimeTableMaker.load_sequencing()
    blocking = masterTimeTableMaker.load_blocking()
    rooms_dict, id_to_num = masterTimeTableMaker.load_rooms()
    course_names = {}
    path_names = "MileStone2Update/data/CourseNameTable.csv"
    if os.path.exists(path_names):
        with open(path_names, encoding='utf-8') as f:
            for row in csv.reader(f):
                if len(row) >= 2:
                    course_names[row[0].strip()] = row[1].strip()

    print("\nVerifying blocking rules...")
    pct, ok, tot = verify_blocking(master, blocking)
    print(f"  ✓ {ok}/{tot} rules satisfied ({pct:.1f}%)\n")

    print("Assigning students to sections...")
    sts, sec_counts = assign_students(students, courses, master, sequencing)
    print(f"  ✓ {len(sts)} students processed\n")

    print("Computing metrics...")
    metrics = compute_metrics(sts, sec_counts, master, courses, rooms_dict, blocking)
    print_metrics(metrics)
    print_section_enrollments(metrics['section_enrollments'], course_names)

    print("\nExporting CSV files...")
    export_master_csv_crosstab(master, sec_counts, course_names, id_to_num, 'master_timetable.csv')
    export_student_csv(master, sts, course_names, id_to_num)

    """
    repaired = load_schedule_for_repair()
    repaired, nsect_counts = repair_schedules(repaired, master, sec_counts)
    repaired = format_for_metrics(repaired)
    new_metrics = compute_metrics(repaired, nsect_counts, master, courses, rooms_dict, blocking)
    print()
    print("REPAIRED SCHEDULE!")
    print_metrics(new_metrics)

    print()
    """
    

    # BONUS: exactly 8 primary requests, all placed, all 8 blocks filled, no alternates in blocks
    full_sts = [st for st in sts
                if len(st['requests']) == 8
                and all(r in st['placed'] for r in st['requests'])
                and len(st['timetable']) == 8
                and all(c in st['requests'] for c in st['timetable'].values())]

    print(f"\n{'='*72}")
    print("  BONUS: 3 STUDENTS WITH ALL 8 REQUESTED COURSES PLACED (no alternates)")
    print("="*72)
    if len(full_sts) >= 3:
        for st in random.sample(full_sts, 3):
            print(f"\n  Student {st['id']}  (Grade {st['grade']})")
            for sem in (1,2):
                for blk in ['A','B','C','D']:
                    c = st['timetable'].get((sem, blk))
                    if c:
                        name = course_names.get(c, c)
                        tag = ' ★' if c in st['requests'] else ''
                        print(f"    Sem{sem}-{blk}: {name}{tag}")
        # OO courses (if any – but with len(timetable)==8, there should be none)
        oo_courses = [c for c in st['placed'] if c not in [v for v in st['timetable'].values()]]
        if oo_courses:
            for c in oo_courses:
                name = course_names.get(c, c)
                tag = ' ★' if c in st['requests'] else ''
                print(f"    Out of Timetable: {name}{tag}")
    else:
        print(f"  Only {len(full_sts)} fully-scheduled students found.")
    print("\nDone.\n")

if __name__ == '__main__':
    main()
