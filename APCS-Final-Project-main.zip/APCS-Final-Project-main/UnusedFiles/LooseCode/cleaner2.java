import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class cleaner2{
    public static void main(String[] args) throws IOException {
        File in = new File("data/old/Course Number of Sections.csv");
        File output = new File("data/cnsClean.csv");
        FileWriter out = new FileWriter(output);
        Scanner read = new Scanner(in);
        String out1 = "";
        String out2 = "";
        while (read.hasNext()){
            String[] temp = read.nextLine().split(",");
            if (temp.length <= 2){
                continue;
            } else if (temp[1].equals("Course") || temp[1].equals("")) {
                continue;
            } else {
                out.write(temp[1]+","+temp[2]+'\n');
            }
        }
        out.close();
    }
}