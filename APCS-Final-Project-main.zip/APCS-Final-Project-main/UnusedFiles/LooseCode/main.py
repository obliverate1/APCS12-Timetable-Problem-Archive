from ortools.sat.python import cp_model
import pandas as pd
from Student import Student

df = pd.read_csv("data/Course Selection by student.csv")

students = []

# C01 - C08 is chosen main courses. C09 and after are alternate courses or out of time table course. 
course_columns = [ "C01","C02","C03","C04", "C05","C06","C07","C08"]
alter_course_columns = ["C09","C10","C11","C12"]

for row in df.itertuples(index=False, name="StudentRow"):
    courses = [getattr(row, col) for col in course_columns if pd.notna(getattr(row, col))]
    alter_courses = [getattr(row, col) for col in alter_course_columns if pd.notna(getattr(row, col))]
    student = Student(student_id=row.ID, yog=row.YOG, requested_courses=courses, alternate_courses=alter_courses)

    students.append(student)


for s in students:
    print(s)