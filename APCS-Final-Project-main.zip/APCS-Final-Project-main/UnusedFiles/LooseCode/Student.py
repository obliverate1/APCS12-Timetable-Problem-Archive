from dataclasses import dataclass, field


@dataclass
class Student:
    student_id: int
    yog: int
    requested_courses: list[str] = field(default_factory=list)
    alternate_courses: list[str] = field(default_factory=list)
    


