import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class cleaner{
    public static void main(String[] args) throws IOException {
        File in = new File("data/old/cleanedstudentrequests.csv");
        File output = new File("data/csrClean.csv");
        FileWriter out = new FileWriter(output);
        Scanner read = new Scanner(in);
        String out1 = "";
        String out2 = "";
        Integer IDCount = 1000;
        while (read.hasNext()){
            String[] temp = read.nextLine().split(",");
            if (temp[0].equals("ID")){
                if (!out1.equals("")){
                    out.write(out1.substring(0, out1.length()-1) + '\n');
                }
                if (!out2.equals("")){
                    out.write(out2.substring(0, out2.length()-1) + '\n');
                }
                if (!temp[3].equals("0")){
                out.write(IDCount.toString() + '\n');   
                IDCount++;                 
                }
                out1 = "";
                out2 = "";
            } else if (temp[0].equals("Course")){
                //do nothing
            } else {
                if (temp[11].equals("Y")){
                    out2 += temp[0]+",";
                } else {
                    out1 += temp[0]+",";
                }
            }
        }
        out.close();
    }
}