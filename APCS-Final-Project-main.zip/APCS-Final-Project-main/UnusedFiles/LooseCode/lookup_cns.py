import csv
import sys
from pathlib import Path

CSV_PATH = Path(__file__).resolve().parent / "data" / "CourseNameTable.csv"


def load_cns_lookup(csv_path=CSV_PATH):
    lookup = {}
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.reader(f)
        for row in reader:
            if len(row) >= 2:
                code = row[0].strip()
                description = row[1].strip()
                lookup[code] = description
    return lookup


def lookup_course(course_code, csv_path=CSV_PATH):
    lookup = load_cns_lookup(csv_path)
    return lookup.get(course_code.strip())


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python lookup_cns.py <course_code>")
        print("Example: python lookup_cns.py ACAL-12---")
        sys.exit(1)

    code = sys.argv[1]
    result = lookup_course(code)
    if result is None:
        print(f"No entry found for '{code}' in {CSV_PATH}")
        sys.exit(2)

    print(result)
