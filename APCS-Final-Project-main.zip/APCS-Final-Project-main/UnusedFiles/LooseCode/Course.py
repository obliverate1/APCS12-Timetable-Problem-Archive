from dataclasses import dataclass, field


@dataclass
class Course:
    course_id: str
    description: str = ""
    num_sections: int = 1
    # Each section is assigned a block (1-8). None = unassigned.
    section_blocks: list[int | None] = field(default_factory=list)

    def __post_init__(self):
        if not self.section_blocks:
            self.section_blocks = [None] * self.num_sections

    def __repr__(self):
        return (
            f"Course(id={self.course_id!r}, sections={self.num_sections}, "
            f"blocks={self.section_blocks})"
        )