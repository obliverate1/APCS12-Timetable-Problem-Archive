import csv
import os
from ortools.sat.python import cp_model
from collections import defaultdict


def load_data():
    # 1. Load sections, schedule types, and room types
    sections = {}
    course_types = {}
    course_room_types = {}
    with open('data/sections.csv', mode='r') as f:
        reader = csv.reader(f)
        next(reader, None)  # Skip header
        for row in reader:
            if not row: continue
            course = row[0].strip()
            num = int(row[1].strip())
            sched_type = row[2].strip().upper() if len(row) > 2 and row[2].strip() else 'ED'
            room_type = row[3].strip() if len(row) > 3 and row[3].strip() else 'Classroom'
            sections[course] = num
            course_types[course] = sched_type
            course_room_types[course] = room_type

    # 2. Load sequencing
    sequencing = []
    if os.path.exists('data/sequencing.csv'):
        with open('data/sequencing.csv', mode='r') as f:
            reader = csv.reader(f)
            for row in reader:
                if not row or len(row) < 2: continue
                sequencing.append((row[0].strip(), row[1].strip()))

    # 3. Load blocking
    blocking = []
    if os.path.exists('data/blocking.csv'):
        with open('data/blocking.csv', mode='r') as f:
            reader = csv.reader(f)
            for row in reader:
                if not row: continue
                courses = []
                for cell in row:
                    for part in cell.split(','):
                        c_clean = part.strip()
                        # Clean out relationship flags ('s', 'n', 'c')
                        if c_clean and c_clean.lower() not in ['s', 'n', 'c']:
                            courses.append(c_clean)
                if len(courses) > 1:
                    blocking.append(courses)
                    
    # 4. Load rooms mapping from roomsClean.csv
    rooms_by_type = {}
    all_rooms = []
    if os.path.exists('data/roomsClean.csv'):
        with open('data/roomsClean.csv', mode='r') as f:
            reader = csv.reader(f)
            next(reader, None)  # Skip header row if present
            for row in reader:
                if not row: continue
                try:
                    r_num = int(row[0].strip())
                    r_type = row[1].strip()
                    all_rooms.append(r_num)
                    if r_type not in rooms_by_type:
                        rooms_by_type[r_type] = []
                    rooms_by_type[r_type].append(r_num)
                except ValueError:
                    continue
                    
    # Fallback to standard room range if roomsClean.csv is missing or empty
    if not all_rooms:
        all_rooms = list(range(500, 549))
        rooms_by_type = {'Classroom': all_rooms}
                    
    return sections, sequencing, blocking, course_types, course_room_types, rooms_by_type, all_rooms

def generate_timetable():
    sections, sequencing, blocking, course_types, course_room_types, rooms_by_type, all_rooms = load_data()

    # --- Pre-process Blocking Groups to Treat Them as One Single Course ---
    # Run in a loop until section counts stabilize to handle chained/overlapping blocks
    while True:
        changes_made = False
        for block_group in blocking:
            valid_courses = [c for c in block_group if c in sections]
            if not valid_courses: continue
            
            # Determine the maximum section count for this merged course entity
            max_sections = max(sections[c] for c in valid_courses)
            
            # Determine a unified schedule type for the group
            types_in_group = {course_types[c] for c in valid_courses if c in course_types}
            if 'ED' in types_in_group:
                group_type = 'ED'
            elif 'MWF' in types_in_group:
                group_type = 'MWF'
            elif 'OO' in types_in_group:
                group_type = 'OO'
            else:
                group_type = 'ED'
                
            # Determine a unified room type for the group
            room_types_in_group = [course_room_types[c] for c in valid_courses if c in course_room_types]
            group_room_type = room_types_in_group[0] if room_types_in_group else 'Classroom'
            
            # Overwrite configurations and track if any values actually changed
            for c in block_group:
                if sections.get(c) != max_sections or course_types.get(c) != group_type or course_room_types.get(c) != group_room_type:
                    sections[c] = max_sections
                    course_types[c] = group_type
                    course_room_types[c] = group_room_type
                    changes_made = True
                    
        # If a full pass happens without any changes, the chains are fully synchronized
        if not changes_made:
            break

    # Define individual course sections
    all_sections = []
    for course, num in sections.items():
        for i in range(num):
            all_sections.append((course, i))

    # --- Union-Find for Blocked Courses ---
    parent = {sec: sec for sec in all_sections}

    def find(sec):
        if parent[sec] == sec:
            return sec
        parent[sec] = find(parent[sec])
        return parent[sec]

    def union(sec1, sec2):
        root1 = find(sec1)
        root2 = find(sec2)
        if root1 != root2:
            parent[root1] = root2

    for block_group in blocking:
        valid_courses = [c for c in block_group if c in sections]
        if len(valid_courses) < 2: continue
        
        max_sections = max(sections[c] for c in valid_courses)
        # Apply the blocking rule separately to each matching section index
        for i in range(max_sections):
            first_sec = (valid_courses[0], i)
            for alternate_course in valid_courses[1:]:
                union(first_sec, (alternate_course, i))

    # Group sections into shared Sessions
    sessions_dict = {}
    for sec in all_sections:
        root = find(sec)
        if root not in sessions_dict:
            sessions_dict[root] = []
        sessions_dict[root].append(sec)

    sessions = list(sessions_dict.values())

    # Resolve schedule type and room type per composite session group
    session_types = []
    session_room_types = []
    for session_sections in sessions:
        types_in_session = {course_types[course] for course, _ in session_sections}
        if 'ED' in types_in_session:
            s_type = 'ED'
        elif 'MWF' in types_in_session:
            s_type = 'MWF'
        elif 'OO' in types_in_session:
            s_type = 'OO'
        else:
            s_type = 'ED'
        session_types.append(s_type)
        
        room_types_in_session = {course_room_types[course] for course, _ in session_sections if course in course_room_types}
        s_room_type = list(room_types_in_session)[0] if room_types_in_session else 'Classroom'
        session_room_types.append(s_room_type)


    # --- INSERT THE BOTTLENECK CHECK HERE ---
    is_impossible = check_room_capacities(sessions, session_types, session_room_types, rooms_by_type)
    if is_impossible:
        print("Stopping early: Schedule is mathematically impossible based on room capacity.")
        return
    # ----------------------------------------

    # --- CP-SAT Solver Setup ---
    model = cp_model.CpModel()

    BLOCKS = ['a', 'b', 'c', 'd']

    sem_vars = []
    block_vars = []
    room_vars = []
    day_half_vars = {}
    global_slot_vars = []

    for idx in range(len(sessions)):
        s_type = session_types[idx]
        s_room_type = session_room_types[idx]
        
        sem = model.NewIntVar(1, 2, f'sem_{idx}')
        sem_vars.append(sem)
        
        if s_type == 'OO':
            block = model.NewIntVar(0, 0, f'block_{idx}')
            room = model.NewIntVar(0, 0, f'room_{idx}')
            block_vars.append(block)
            room_vars.append(room)
            day_half_vars[idx] = None
        else:
            block = model.NewIntVar(0, len(BLOCKS) - 1, f'block_{idx}')
            
            # Fetch valid rooms matching the session's required room type
            allowed_rooms = rooms_by_type.get(s_room_type, [])
            if not allowed_rooms:
                allowed_rooms = all_rooms if all_rooms else [500]
                
            # Restrict the room variable using a specialized CP-SAT Domain constraint
            room_domain = cp_model.Domain.FromValues(allowed_rooms)
            room = model.NewIntVarFromDomain(room_domain, f'room_{idx}')
            
            block_vars.append(block)
            room_vars.append(room)
            
            if s_type == 'ED':
                day_half_vars[idx] = None
                global_slot_0 = model.NewIntVar(0, 200000, f'global_slot_{idx}_d0')
                global_slot_1 = model.NewIntVar(0, 200000, f'global_slot_{idx}_d1')
                model.Add(global_slot_0 == room + 1000 * block + 10000 * sem + 100000 * 0)
                model.Add(global_slot_1 == room + 1000 * block + 10000 * sem + 100000 * 1)
                global_slot_vars.append(global_slot_0)
                global_slot_vars.append(global_slot_1)
                
            elif s_type == 'MWF':
                day_half = model.NewIntVar(0, 1, f'day_half_{idx}')
                day_half_vars[idx] = day_half
                
                global_slot = model.NewIntVar(0, 200000, f'global_slot_{idx}')
                model.Add(global_slot == room + 1000 * block + 10000 * sem + 100000 * day_half)
                global_slot_vars.append(global_slot)

    if global_slot_vars:
        model.AddAllDifferent(global_slot_vars)

    # --- Sequencing Constraint ---
    sec_to_session_idx = {}
    for idx, session_sections in enumerate(sessions):
        for sec in session_sections:
            sec_to_session_idx[sec] = idx

    for course_pre, course_post in sequencing:
        if course_pre in sections and course_post in sections:
            for s_pre in range(sections[course_pre]):
                for s_post in range(sections[course_post]):
                    idx_pre = sec_to_session_idx[(course_pre, s_pre)]
                    idx_post = sec_to_session_idx[(course_post, s_post)]
                    model.Add(sem_vars[idx_pre] < sem_vars[idx_post])

    # --- Semester Balancing Objective ---
    sem1_vars = []
    weights = []
    for idx, session_sections in enumerate(sessions):
        sem1_var = model.NewBoolVar(f'sem1_{idx}')
        model.Add(sem_vars[idx] == 1).OnlyEnforceIf(sem1_var)
        model.Add(sem_vars[idx] == 2).OnlyEnforceIf(sem1_var.Not())
        sem1_vars.append(sem1_var)
        weights.append(len(session_sections))
        
    total_sections = sum(weights)
    target = total_sections // 2
    
    sem1_sum = model.NewIntVar(0, total_sections, 'sem1_sum')
    model.Add(sem1_sum == sum(sem1_vars[i] * weights[i] for i in range(len(sem1_vars))))
    
    diff = model.NewIntVar(-total_sections, total_sections, 'diff')
    model.Add(diff == sem1_sum - target)
    
    abs_diff = model.NewIntVar(0, total_sections, 'abs_diff')
    model.AddAbsEquality(abs_diff, diff)
    
    model.Minimize(abs_diff)

    # --- Solve ---
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 60.0
    status = solver.Solve(model)

    if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        master = defaultdict(list)
        output_rows = []
        for idx, session_sections in enumerate(sessions):
            s_type = session_types[idx]
            s_sem = solver.Value(sem_vars[idx])
            
            if s_type == 'OO':
                s_block = 'OO'
                s_room = 'N/A'
                s_pattern = 'Out of TT'
            else:
                s_block = BLOCKS[solver.Value(block_vars[idx])].upper()
                s_room = solver.Value(room_vars[idx])
                if s_type == 'ED':
                    s_pattern = 'Every Day'
                elif s_type == 'MWF':
                    dh = solver.Value(day_half_vars[idx])
                    s_pattern = 'MWF (Day A)' if dh == 0 else 'TT (Day B)'
            
            for course, sec_num in session_sections:

                # Milestone 2 master structure
                master[course].append({
                    'section': sec_num + 1,
                    'semester': s_sem,
                    'block': s_block,
                    'room': s_room,
                    'type': s_type,
                    'pattern': s_pattern
                })

                # Optional CSV/export structure
                output_rows.append({
                    'Semester': s_sem,
                    'Block': s_block,
                    'Room': s_room,
                    'Course Code': course,
                    'Section': sec_num + 1,
                    'Type': s_type,
                    'Pattern': s_pattern
                })
                    
        output_rows.sort(key=lambda x: (
            x['Semester'], 
            x['Block'], 
            999 if x['Room'] == 'N/A' else x['Room'], 
            x['Course Code'],
            x['Section']
        ))
        
        # --- NEW EXPORT FORMAT FOR CSV ---
        output_filename = 'timetable_output.csv'
        with open(output_filename, mode='w', newline='') as f:
            writer = csv.writer(f)
            
            # Dynamically compile the list of blocks used
            blocks_list = [b.upper() for b in BLOCKS]
            if any(row['Block'] == 'OO' for row in output_rows):
                blocks_list.append('OO')
            
            num_cols_per_sem = len(blocks_list)
            
            # Row 1: Title
            writer.writerow(["Master Timetable"] + [""] * (2 * num_cols_per_sem - 1))
            
            # Row 2: Semester Headers
            writer.writerow(["Semester 1"] + [""] * (num_cols_per_sem - 1) + ["Semester 2"] + [""] * (num_cols_per_sem - 1))
            
            # Row 3: Block Headers
            writer.writerow([f"Block {b}" if b != 'OO' else "OO" for b in blocks_list] * 2)
            
            # Structure data into columns
            columns_data = {(sem, block): [] for sem in [1, 2] for block in blocks_list}
            for row in output_rows:
                sem = row['Semester']
                block = row['Block']
                entry = f"{row['Course Code']} (Sec {row['Section']})"
                if (sem, block) in columns_data:
                    columns_data[(sem, block)].append(entry)
            
            # Determine max row depth needed for any block
            max_rows = max(len(columns_data[(sem, block)]) for sem in [1, 2] for block in blocks_list) if columns_data else 0
            
            # Row 4+: List courses sequentially under each block column
            for i in range(max_rows):
                current_row = []
                for sem in [1, 2]:
                    for block in blocks_list:
                        if i < len(columns_data[(sem, block)]):
                            current_row.append(columns_data[(sem, block)][i])
                        else:
                            current_row.append("")
                writer.writerow(current_row)
            
        print(f"Results successfully saved to '{output_filename}'\n")

        print(f"{'Sem':<5} | {'Block':<6} | {'Room':<5} | {'Course':<10} | {'Section':<7} | {'Type':<5} | {'Pattern'}")
        print("-" * 65)
        for row in output_rows:
            print(f"{row['Semester']:<5} | {row['Block']:<6} | {row['Room']:<5} | {row['Course Code']:<10} | {row['Section']:<7} | {row['Type']:<5} | {row['Pattern']}")
    else:
        print("Failed: No valid schedule configuration found satisfying all parameters.")

    return dict(master)



def check_room_capacities(sessions, session_types, session_room_types, rooms_by_type):
    print("\n==================================================")
    print("           ROOM CAPACITY BOTTLENECK REPORT        ")
    print("==================================================")
    
    # 1. Calculate slot demand per room type across all sessions
    demand_by_type = {}
    for idx, r_type in enumerate(session_room_types):
        s_type = session_types[idx]
        if s_type == 'OO':
            continue  # Out of timetable ignores rooms
            
        # ED sessions take 2 half-slots (Day A + Day B), MWF takes 1 half-slot
        slots_needed = 2 if s_type == 'ED' else 1
        demand_by_type[r_type] = demand_by_type.get(r_type, 0) + slots_needed
        
    has_critical_failure = False
    
    # 2. Analyze supply vs demand for known room types
    all_room_types = set(list(rooms_by_type.keys()) + list(demand_by_type.keys()))
    
    for r_type in sorted(all_room_types):
        rooms = rooms_by_type.get(r_type, [])
        num_rooms = len(rooms)
        
        # Capacity formula: rooms * 4 blocks * 2 day-halves * 2 semesters
        total_supply = num_rooms * 16 
        demand = demand_by_type.get(r_type, 0)
        
        utilization = (demand / total_supply) * 100 if total_supply > 0 else 0
        
        print(f"Room Type: [ {r_type} ]")
        print(f"  - Physical Rooms Available: {num_rooms} (Total capacity: {total_supply} half-slots)")
        print(f"  - Total Requested Demand:   {demand} half-slots")
        
        if num_rooms == 0 and demand > 0:
            print(f"  ❌ CRITICAL ERROR: Courses require '{r_type}' rooms, but 0 exist in roomsClean.csv!")
            has_critical_failure = True
        elif demand > total_supply:
            print(f"  ❌ CRITICAL BOTTLENECK: You are short by {demand - total_supply} slots! (Utilization: {utilization:.1f}%)")
            has_critical_failure = True
        elif utilization > 87.5:
            print(f"  ⚠️ HIGH RISK ({utilization:.1f}%): Technically enough slots, but too tightly packed.")
            print(f"     Sequencing or semester balancing constraints will likely cause solver failure.")
        else:
            print(f"  ✅ OK ({utilization:.1f}% utilized)")
        print("-" * 50)
        
    print("==================================================\n")
    return has_critical_failure







if __name__ == '__main__':
    generate_timetable()