import csv
import os
from Student import Student


def load_students(filepath: str) -> list[Student]:
    """
    Parse cleanedstudentrequests.csv into a list of Student objects.

    CSV structure (repeats per student):
        ID, <student_id>, Grade, ...      <- student header row
        Course, , , , Description, ...   <- column header (skipped)
        <course_code>, ..., Y/N, ...      <- course row; col 11 = Alternate flag
    """
    students: list[Student] = []
    current_id = None
    requested: list[str] = []
    alternates: list[str] = []

    with open(filepath, newline='', encoding='utf-8-sig') as f:
        for row in csv.reader(f):
            if not row:
                continue
            first = row[0].strip()

            if first == 'ID' and len(row) > 1 and row[1].strip():
                if current_id is not None:
                    students.append(Student(current_id, requested, alternates))
                try:
                    current_id = int(float(row[1].strip()))
                except ValueError:
                    current_id = None
                requested, alternates = [], []

            elif first == 'Course':
                continue

            elif current_id is not None and first not in ('', 'ID'):
                is_alt = len(row) > 11 and row[11].strip() == 'Y'
                (alternates if is_alt else requested).append(first)

    if current_id is not None:
        students.append(Student(current_id, requested, alternates))

    return students


if __name__ == '__main__':
    path = os.path.join(os.path.dirname(__file__), 'data', 'cleanedstudentrequests.csv')
    students = load_students(path)
    print(f"Total students: {len(students)}")
    for s in students:
        print(s)