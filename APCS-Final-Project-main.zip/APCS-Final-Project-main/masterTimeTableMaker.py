import csv, os
from collections import defaultdict
from ortools.sat.python import cp_model

BLOCKS = ['A', 'B', 'C', 'D']
SEMESTERS = [1, 2]
DATA_DIR = 'data'
DEFAULT_MAX_CAPACITY = 30
LAB_MAX_CAPACITY = 24
LAB_COURSE_PREFIXES = ('MATPH','MCH','MPH-','MEVSC','MWWK',
                       'MTAUT','MTEAD','MTROB','MMACS','MCMPR','MTDRF')

SCI_COURSE_PREFIXES = ('MATPH','MCH','MPH-', 'APHM', 'MEVSC', 'MSC', )

MATH_COURSE_PREFIXES = ('MCALC','MPREC','MFMP','MFOM','MMA','MWPM',
                             'ACAL','ASTA')

MATH_ROOMS = {505,524,526,527,530,531}

SCI_ROOMS = {525,528,529,533,534,535,536}

SPECIALTY_ONLY_ROOMS = {500,501,502,503,504,514,515,541,547,548, 511, 520, 521}

def load_rooms():
    rooms = {}
    id_to_num = {}
    with open(f"{DATA_DIR}/roomsClean.csv", encoding='utf-8-sig') as f:
        for row in csv.reader(f):
            if not row or row[0].strip() in ('','ID'): continue
            try:
                rid = int(row[0].strip())
                department = row[1].strip()
                room_num = row[2].strip()
                rooms[rid] = department
                id_to_num[rid] = room_num
            except ValueError:
                continue
    return rooms, id_to_num

def general_pool(rooms_dict):
    return sorted(r for r in rooms_dict if r not in SPECIALTY_ONLY_ROOMS)

def get_allowed_rooms(code, rooms_dict, gpool=None, id_to_num=None):
    if code.startswith(('Y','X','PBB')) and not code.startswith(('XBA')): return []
    # Specialty rooms
    if code.startswith(('MWWK','MADW')): return [500]
    if code.startswith(('MTAUT','MTEAD')): return [501]
    if code.startswith(('MTPOW',)): return [502]
    if code.startswith(('MADER','MTROB','MTEAR','MTEXP','MENR')): return [503]
    if code.startswith(('MTDRF','MADD','MADGE')): return [504]
    if code.startswith(('MDRM','MDR--')): return [541]
    if code.startswith(('MDCF','MDNC','MDN')): return [548]
    if code.startswith(('MIMG','MIMC','MMUC','MMUJ','MMUO','MCMCC','MMUCC','XC','MIMCB','MIMJB','MMUCB','MMUJB','MMUOR','XC','XLDCB')): return [514]
    if code.startswith(('MPHE','MPHED','MACLV')): return [547]

    if code.startswith(('XBA--09C-L', 'MPHED10--L', 'MPHE-09--L', 'MMUCB10--L', 'MMUOR10S-L' )): return [549]

    if code.startswith(('ACSC', 'MMACS12')): return [520]
    if code.startswith(('MMACS','MCMPR','MWBDV')): return [520,511]
    if code.startswith(('MCLE')): return [519]
    if code.startswith(('MTXT')): return [546]
    if code.startswith(('MADT')): return [546]
    if code.startswith(('YPA', 'MPHE-09Y--')): return [515]

    if code.startswith(('MATPH','MCH','MPH-', 'APHM', 'MEVSC', 'MSC')): return [525,528,529,533,534,535,536]
    if code.startswith(('MCALC','MPREC','MFMP','MFOM','MMA','MWPM','ACAL','ASTA')): return [505,524,526,527,530,531]

    if code.startswith(('MFOOD',)): return [521] 
    if code.startswith(('MVAST', 'MVA')): return [512]
    if code.startswith(('MMEDD')): return [511]

    if gpool is None: gpool = general_pool(rooms_dict)

    return gpool

def load_courses():
    courses = {}
    with open(f"{DATA_DIR}/sections.csv") as f:
        for row in csv.reader(f):
            if not row: continue
            code = row[0].strip()
            n_sec = int(row[1].strip())
            sched = row[2].strip().upper() if len(row)>2 and row[2].strip() else 'ED'
            if code.startswith(('Y','X','PBB')) and not code.startswith(('XBA')):
                sched = 'OO'
            room_type = row[3].strip() if len(row)>3 and row[3].strip() else 'Classroom'
            courses[code] = {'sections': n_sec, 'type': sched, 'room_type': room_type}
    return courses

def load_required_courses():
    required = set()
    path = f"{DATA_DIR}/required_courses.csv"
    if os.path.exists(path):
        with open(path) as f:
            for line in f:
                code = line.strip().strip('"')
                if code and not code.startswith('#'):
                    required.add(code)
    return required

def load_sequencing():
    pairs = []
    path = f"{DATA_DIR}/sequencing.csv"
    if not os.path.exists(path): return pairs
    with open(path) as f:
        for line in f:
            codes = [c.strip().strip('"') for c in line.strip().strip('"').split(',') if c.strip().strip('"')]
            for i in range(len(codes)-1):
                pairs.append((codes[i], codes[i+1]))
    return pairs

def load_blocking():
    groups = []
    path = f"{DATA_DIR}/blocking.csv"
    if not os.path.exists(path):
        return groups
    with open(path) as f:
        for raw in f:
            line = raw.strip().strip('"')
            if not line:
                continue
            codes = [c.strip() for c in line.split(',') if c.strip().lower() not in ('s', 'n', 'c', '')]
            if len(codes) > 1:
                groups.append(codes)
    return groups

def course_max_capacity(code):
    return LAB_MAX_CAPACITY if any(code.startswith(p) for p in LAB_COURSE_PREFIXES) else DEFAULT_MAX_CAPACITY

def load_students():
    students, current = [], None
    with open(f"{DATA_DIR}/cleanedstudentrequests.csv", encoding='utf-8-sig') as f:
        for row in csv.reader(f):
            if not row: continue
            col0 = row[0].strip()
            if col0 == 'ID':
                if current: students.append(current)
                sid = int(row[1].strip())
                grade = int(row[3].strip()) if len(row)>3 and row[3].strip().isdigit() else 0
                current = {'id':sid,'grade':grade,'requests':[],'alternates':[]}
            elif col0 in ('Course','') or not col0:
                continue
            elif current is not None:
                is_alt = len(row)>10 and row[10].strip().upper()=='Y'
                if is_alt: current['alternates'].append(col0)
                else:       current['requests'].append(col0)
    if current: students.append(current)
    return students

def adjust_sections_by_demand(courses, students, blocking_groups):
    demand = defaultdict(int)
    for s in students:
        for req in s['requests']:
            demand[req] += 1

    # Build mapping from course to its blocking group (first group only)
    course_to_group = {}
    group_id = 0
    for grp in blocking_groups:
        for code in grp:
            if code not in course_to_group:
                course_to_group[code] = group_id
        group_id += 1
    # Courses not in any block become their own group
    for code in courses:
        if code not in course_to_group:
            course_to_group[code] = group_id
            group_id += 1

    groups = defaultdict(list)
    for code, gid in course_to_group.items():
        groups[gid].append(code)

    adjusted = {}
    for gid, codes in groups.items():
        # Is this a real blocking group (more than one course)?
        is_blocked = len(codes) > 1

        max_sections = 0
        for code in codes:
            info = courses.get(code)
            if not info:
                continue
            cap = course_max_capacity(code)
            orig = info['sections']
            d = demand.get(code, 0)

            if is_blocked:
                # Blocked courses: ignore half‑fill rule.
                if cap > 0 and d > 0:
                    needed = (d + cap - 1) // cap   # ceil division
                else:
                    needed = 0
                needed = min(orig, needed)
                if d == 0:
                    needed = 0
            else:
                # Non‑blocked courses: apply half‑fill rule as before
                if cap > 0:
                    if d < cap // 2:
                        needed = 0
                    else:
                        needed = (d - cap//2) // cap + 1
                else:
                    needed = 0
                needed = min(orig, needed)

            if needed > max_sections:
                max_sections = needed

        if max_sections == 0:
            print(f"  ✗ Group {codes} has insufficient demand → all courses removed.")
            continue

        # Assign the same number of sections to every course in the group
        for code in codes:
            if code not in courses:
                continue  
            info = courses[code]
            adjusted[code] = {
                'sections': max_sections,
                'type': info['type'],
                'room_type': info['room_type']
            }

    # Keep OO courses even if they were dropped
    for code, info in courses.items():
        if info['type'] == 'OO' and code not in adjusted:
            adjusted[code] = info.copy()

    return adjusted

def make_sessions(non_oo, blocking_groups):
    all_secs = [(c,i) for c,info in non_oo.items() for i in range(info['sections'])]
    parent = {s:s for s in all_secs}
    def find(s):
        while parent[s]!=s:
            parent[s]=parent[parent[s]]; s=parent[s]
        return s
    def union(a,b):
        ra,rb = find(a),find(b)
        if ra!=rb: parent[ra]=rb
    for grp in blocking_groups:
        valid = [c for c in grp if c in non_oo]
        if len(valid)<2: continue
        mn = min(non_oo[c]['sections'] for c in valid)
        for i in range(mn):
            for c in valid[1:]:
                union((valid[0],i),(c,i))
    sm = defaultdict(list)
    for s in all_secs: sm[find(s)].append(s)
    return list(sm.values())

def build_master_timetable(courses, blocking_groups, rooms_dict, id_to_num, required_courses=None):
    if required_courses is None:
        required_courses = set()
    
    non_oo = {c:i for c,i in courses.items() if i['type']!='OO' and i['sections']>0}
    oo_courses = {c:i for c,i in courses.items() if i['type']=='OO' and i['sections']>0}
    gpool = general_pool(rooms_dict)
    sessions = make_sessions(non_oo, blocking_groups)
    n = len(sessions)
    nb = len(BLOCKS)
    print(f"  Sessions: {n}  |  General pool: {len(gpool)} rooms")
    print(f"  Required courses to prioritize: {len(required_courses)}")

    # Isolate linear sessions vs single-semester sessions
    linear_indices = [i for i, sess in enumerate(sessions) if any(c.endswith('L') for c, _ in sess)]
    normal_indices = [i for i in range(n) if i not in linear_indices]
    num_normal = len(normal_indices)

    model = cp_model.CpModel()
    
    # Map normal sessions to a compact set of CP-SAT variables
    normal_idx_to_var_idx = {idx: i for i, idx in enumerate(normal_indices)}
    sem_vars = [model.NewIntVar(1, 2, f'sem_{i}') for i in range(num_normal)]
    
    sequencing = load_sequencing()
    sec_to_idx = {}
    for idx, sess in enumerate(sessions):
        for sec in sess:
            sec_to_idx[sec] = idx
            
    for pre, post in sequencing:
        if pre not in non_oo or post not in non_oo:
            continue
        for i in range(non_oo[pre]['sections']):
            for j in range(non_oo[post]['sections']):
                ip = sec_to_idx.get((pre,i))
                iq = sec_to_idx.get((post,j))
                if ip is not None and iq is not None:
                    if ip in normal_idx_to_var_idx and iq in normal_idx_to_var_idx:
                        v_ip = normal_idx_to_var_idx[ip]
                        v_iq = normal_idx_to_var_idx[iq]
                        model.Add(sem_vars[v_ip] < sem_vars[v_iq])

    req_indices = [idx for idx in normal_indices
                   if any(course in required_courses for (course, _) in sessions[idx])]

    for i, idx in enumerate(req_indices):
        v_idx = normal_idx_to_var_idx[idx]
        if i % 2 == 0:
            model.Add(sem_vars[v_idx] == 1)
        else:
            model.Add(sem_vars[v_idx] == 2)
            
    weights = [len(sessions[idx]) for idx in normal_indices]
    total_w = sum(weights)
    target = total_w // 2
    
    if num_normal > 0:
        bools = [model.NewBoolVar(f'b_{i}') for i in range(num_normal)]
        for i in range(num_normal):
            model.Add(sem_vars[i]==1).OnlyEnforceIf(bools[i])
            model.Add(sem_vars[i]==2).OnlyEnforceIf(bools[i].Not())
        s1sum = model.NewIntVar(0,total_w,'s1sum')
        model.Add(s1sum == sum(bools[i]*weights[i] for i in range(num_normal)))
        diff = model.NewIntVar(-total_w,total_w,'diff')
        abs_diff = model.NewIntVar(0,total_w,'abs_diff')
        model.Add(diff == s1sum - target)
        model.AddAbsEquality(abs_diff, diff)
        model.Minimize(abs_diff)

        solver = cp_model.CpSolver()
        solver.parameters.max_time_in_seconds = 60.0
        solver.parameters.num_search_workers = 4
        status = solver.Solve(model)
        
        semesters = {}
        if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            for idx in normal_indices:
                v_idx = normal_idx_to_var_idx[idx]
                semesters[idx] = solver.Value(sem_vars[v_idx])
            print("  CP‑SAT assigned semesters with priority consideration.")
        else:
            print("  CP‑SAT failed – using fallback semester assignment (based on index).")
            for i, idx in enumerate(normal_indices):
                semesters[idx] = 1 if i < num_normal//2 else 2
    else:
        semesters = {}

    sem1_indices = [idx for idx in normal_indices if semesters[idx]==1]
    sem2_indices = [idx for idx in normal_indices if semesters[idx]==2]
    
    def sort_key(idx):
        is_required = any(course in required_courses for (course, _) in sessions[idx])
        return (0 if is_required else 1, idx)
    
    sem1_indices.sort(key=sort_key)
    sem2_indices.sort(key=sort_key)
    
    session_allowed = []
    for idx, sess in enumerate(sessions):
        allowed_set = None
        for course, _ in sess:
            allowed = set(get_allowed_rooms(course, rooms_dict, gpool, id_to_num))
            if not allowed:
                allowed = set(gpool)
            if allowed_set is None:
                allowed_set = allowed
            else:
                allowed_set &= allowed
        if not allowed_set:
            allowed_set = set(gpool)
        session_allowed.append(allowed_set)

    slot_sessions = defaultdict(list)
    slot_used_rooms = defaultdict(set)
    room_assignment = {}
    
    # 1. Distribute Linear sessions & lock down their shared rooms across BOTH semesters
    for i, idx in enumerate(linear_indices):
        blk = i % nb
        slot_sessions[(1, blk)].append(idx)
        slot_sessions[(2, blk)].append(idx)
        
        allowed_set = session_allowed[idx]
        sorted_allowed = sorted(allowed_set,
                                key=lambda rid: (0 if id_to_num.get(rid, '').startswith('A-') else 1,
                                                 id_to_num.get(rid, '9999')))
        chosen = None
        for r in sorted_allowed:
            # Find a room that is free in BOTH semesters during this specific block
            if r not in slot_used_rooms[(1, blk)] and r not in slot_used_rooms[(2, blk)]:
                chosen = r
                break
        if chosen is None:
            for r in sorted(gpool, key=lambda rid: (0 if id_to_num.get(rid, '').startswith('A-') else 1, id_to_num.get(rid, '9999'))):
                if r not in slot_used_rooms[(1, blk)] and r not in slot_used_rooms[(2, blk)]:
                    chosen = r
                    break
        if chosen is None:
            for r in sorted(rooms_dict.keys(), key=lambda rid: (0 if id_to_num.get(rid, '').startswith('A-') else 1, id_to_num.get(rid, '9999'))):
                if r not in slot_used_rooms[(1, blk)] and r not in slot_used_rooms[(2, blk)]:
                    chosen = r
                    break
        if chosen is None:
            chosen = sorted_allowed[0]
            
        slot_used_rooms[(1, blk)].add(chosen)
        slot_used_rooms[(2, blk)].add(chosen)
        
        for (course, sec_i) in sessions[idx]:
            room_assignment[(course, sec_i)] = chosen

    # 2. Distribute normal single-semester sessions into blocks
    for i, idx in enumerate(sem1_indices):
        blk = i % nb
        slot_sessions[(1, blk)].append(idx)
    for i, idx in enumerate(sem2_indices):
        blk = i % nb
        slot_sessions[(2, blk)].append(idx)
        
    # 3. Assign remaining rooms slot-by-slot to normal sessions
    for (sem, blk), idx_list in slot_sessions.items():
        def priority_sort(idx):
            is_required = any(course in required_courses for (course, _) in sessions[idx])
            return (0 if is_required else 1, len(session_allowed[idx]))
        
        normal_idx_list = [idx for idx in idx_list if idx in normal_indices]
        session_list = sorted([(i, session_allowed[i]) for i in normal_idx_list], 
                            key=lambda x: priority_sort(x[0]))
        
        used_rooms = set(slot_used_rooms[(sem, blk)])
        for i, allowed_set in session_list:
            sorted_allowed = sorted(allowed_set,
                                    key=lambda rid: (0 if id_to_num.get(rid, '').startswith('A-') else 1,
                                                     id_to_num.get(rid, '9999')))
            chosen = None
            for r in sorted_allowed:
                if all(r in get_allowed_rooms(course, rooms_dict, gpool, id_to_num) for (course,_) in sessions[i]):
                    if r not in used_rooms:
                        chosen = r
                        break
            if chosen is None:
                for r in sorted(gpool, key=lambda rid: (0 if id_to_num.get(rid, '').startswith('A-') else 1, id_to_num.get(rid, '9999'))):
                    if r not in used_rooms:
                        chosen = r
                        break
            if chosen is None:
                for r in sorted(rooms_dict.keys(), key=lambda rid: (0 if id_to_num.get(rid, '').startswith('A-') else 1, id_to_num.get(rid, '9999'))):
                    if r not in used_rooms:
                        chosen = r
                        break
            if chosen is None:
                chosen = sorted_allowed[0]
            used_rooms.add(chosen)
            slot_used_rooms[(sem, blk)].add(chosen)
            for (course, sec_i) in sessions[i]:
                room_assignment[(course, sec_i)] = chosen

    # Post-process rooms session-by-session to completely resolve any room conflicts
    gpool_set = set(gpool)
    for (sem, blk), idx_list in slot_sessions.items():
        slot_linear = [idx for idx in idx_list if idx in linear_indices]
        slot_normal = [idx for idx in idx_list if idx in normal_indices]
        
        # Track locked rooms taken by linear sessions first
        used_rooms = set()
        for idx in slot_linear:
            if sessions[idx]:
                r = room_assignment.get(sessions[idx][0])
                if r is not None:
                    used_rooms.add(r)
                    
        # Verify and adjust normal single-semester sessions
        for idx in slot_normal:
            if not sessions[idx]:
                continue
            r = room_assignment.get(sessions[idx][0])
            
            # Verify if the current room assignment is allowed for all courses in this session
            allowed_for_all = True
            for course, sec_i in sessions[idx]:
                allowed = set(get_allowed_rooms(course, rooms_dict, gpool, id_to_num))
                if not allowed:
                    allowed = gpool_set
                if r not in allowed:
                    allowed_for_all = False
                    break
            
            # Resolve if there is a conflict with another session or if the room isn't allowed
            if r in used_rooms or not allowed_for_all:
                common_allowed = None
                for course, sec_i in sessions[idx]:
                    allowed = set(get_allowed_rooms(course, rooms_dict, gpool, id_to_num))
                    if not allowed:
                        allowed = gpool_set
                    if common_allowed is None:
                        common_allowed = allowed
                    else:
                        common_allowed &= allowed
                if not common_allowed:
                    common_allowed = gpool_set
                    
                new_room = None
                # 1. Search intersection of allowed rooms
                for pr in sorted(common_allowed, key=lambda rid: (0 if id_to_num.get(rid, '').startswith('A-') else 1, id_to_num.get(rid, '9999'))):
                    if pr not in used_rooms:
                        new_room = pr
                        break
                # 2. Search general classroom pool
                if new_room is None:
                    for pr in sorted(gpool, key=lambda rid: (0 if id_to_num.get(rid, '').startswith('A-') else 1, id_to_num.get(rid, '9999'))):
                        if pr not in used_rooms:
                            new_room = pr
                            break
                # 3. Search entire building registry
                if new_room is None:
                    for pr in sorted(rooms_dict.keys(), key=lambda rid: (0 if id_to_num.get(rid, '').startswith('A-') else 1, id_to_num.get(rid, '9999'))):
                        if pr not in used_rooms:
                            new_room = pr
                            break
                
                # Apply the resolved room across the entire session block
                if new_room is not None:
                    r = new_room
                    for course, sec_i in sessions[idx]:
                        room_assignment[(course, sec_i)] = r
            
            if r is not None:
                used_rooms.add(r)

    master = defaultdict(list)
    for (sem, blk), idx_list in slot_sessions.items():
        for idx in idx_list:
            for (course, sec_i) in sessions[idx]:
                entry = {
                    'section': sec_i+1,
                    'semester': sem,
                    'block': BLOCKS[blk],
                    'room': room_assignment.get((course, sec_i)),
                    'type': non_oo[course]['type'],
                    'pattern': 'Linear' if course.endswith('L') else ('Every Day' if non_oo[course]['type']=='ED' else 'MWF (Day A/B)'),
                    'priority': 'REQUIRED' if course in required_courses else 'OPTIONAL'
                }
                master[course].append(entry)

    for code, info in oo_courses.items():
        for i in range(info['sections']):
            master[code].append({
                'section': i+1,
                'semester': 1,
                'block': 'OO',
                'room': None,
                'type': 'OO',
                'pattern': 'Out of Timetable',
                'priority': 'REQUIRED' if code in required_courses else 'OPTIONAL'
            })

    for code in master:
        master[code].sort(key=lambda x: (x['semester'], x['block'], x['section']))

    return dict(master)

def export_master_csv_vertical(master, course_names, id_to_num, fname='master_timetable.csv'):
    rows = [['Course Code','Course Name','Section','Semester','Block','Room','Type','Pattern','Priority']]
    sorted_courses = sorted(master, key=lambda c: (0 if any(s.get('priority')=='REQUIRED' for s in master[c]) else 1, c))
    
    for code in sorted_courses:
        for sec in master[code]:
            room_display = id_to_num.get(sec['room'], 'N/A') if sec['room'] is not None else 'N/A'
            rows.append([code, course_names.get(code,''), sec['section'],
                         sec['semester'], sec['block'], room_display,
                         sec['type'], sec['pattern'], sec.get('priority', 'OPTIONAL')])
    with open(fname,'w',newline='') as f:
        csv.writer(f).writerows(rows)
    print(f"  → {fname}")

def generate_timetable():
    print("Loading data...")
    courses_orig = load_courses()
    students = load_students()
    rooms_dict, id_to_num = load_rooms()
    blocking = load_blocking()
    required_courses = load_required_courses()

    courses = adjust_sections_by_demand(courses_orig, students, blocking)

    course_names = {}
    path_names = f"{DATA_DIR}/CourseNameTable.csv"
    if os.path.exists(path_names):
        with open(path_names, encoding='utf-8') as f:
            for row in csv.reader(f):
                if len(row)>=2: course_names[row[0].strip()] = row[1].strip()

    print(f"  Courses after demand adjustment: {len(courses)}  |  Students: {len(students)}  |  Blocking groups: {len(blocking)}")
    print("Building master timetable with course priorities...")
    master = build_master_timetable(courses, blocking, rooms_dict, id_to_num, required_courses)
    tt_sec = sum(1 for v in master.values() for s in v if s['type']!='OO')
    req_sec = sum(1 for v in master.values() for s in v if s.get('priority')=='REQUIRED' and s['type']!='OO')
    print(f"  ✓ {len(master)} courses, {sum(len(v) for v in master.values())} sections ({tt_sec} in‑timetable)")
    print(f"  ✓ {req_sec} required course sections scheduled")
    return master

if __name__ == '__main__':
    generate_timetable()