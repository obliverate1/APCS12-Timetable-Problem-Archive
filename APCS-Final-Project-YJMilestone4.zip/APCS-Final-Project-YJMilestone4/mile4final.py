"""
School Timetabling Problem — Milestone 4 (Greedy Sequencing Fix)
=========================================
Builds a master timetable (course → semester, block, room) with:
- correct number of sections,
- room assignments respecting course type,
- blocking rules (simultaneous courses forced together),
- sequencing rules (prerequisite → later course semester order via Smart Greedy Allocation),
- capacity and minimum‑enrolment constraints,
- then assigns students, respecting all hard constraints.
"""

import csv
import os
import random
import json
from collections import defaultdict
from time import perf_counter_ns

# ========================== CONSTANTS ==========================
BLOCKS = ['A', 'B', 'C', 'D']
SEMESTERS = [1, 2]
DATA_DIR = 'data'

ROOM_MIN = 500
ROOM_MAX = 548

DEFAULT_MAX_CAPACITY = 30
LAB_MAX_CAPACITY = 24

LAB_COURSE_PREFIXES = (
    'MATPH', 'MCH', 'MPH', 'MEVSC',      
    'MWWK',                              
    'MTAUT', 'MTEAD',                    
    'MTROB',                             
    'MMACS', 'MCMPR',                    
    'MTDRF'                              
)

# ========================== LOAD DATA ==========================
def load_courses():
    courses = {}
    with open("data/sections.csv") as f:
        for row in csv.reader(f):
            if not row: continue
            code = row[0].strip()
            num_sec = int(row[1].strip())
            sched = row[2].strip().upper() if len(row) > 2 and row[2].strip() else 'ED'
            if code.startswith(('Y', 'X', 'PBB')):
                sched = 'OO'
            courses[code] = {'sections': num_sec, 'type': sched}
    return courses

def load_students():
    students = []
    current = None
    with open("data/cleanedstudentrequests.csv", encoding='utf-8-sig') as f:
        for row in csv.reader(f):
            if not row: continue
            col0 = row[0].strip()
            if col0 == 'ID':
                if current is not None:
                    students.append(current)
                student_id = int(row[1].strip())
                grade = int(row[3].strip()) if len(row) > 3 and row[3].strip().isdigit() else 0
                current = {'id': student_id, 'grade': grade, 'requests': []}
            elif col0 == 'Course' or not col0:
                continue
            elif current is not None:
                current['requests'].append(col0)
    if current is not None:
        students.append(current)
    return students

def load_sequencing():
    pairs = []
    path = "data/sequence.csv"
    if not os.path.exists(path): return pairs
    with open(path) as f:
        for line in f:
            clean = line.strip().strip('"')
            codes = [c.strip().strip('"') for c in clean.split(',') if c.strip().strip('"')]
            if len(codes) > 1:
                prereq = codes[0]
                for later in codes[1:]:
                    pairs.append((prereq, later))
    return pairs

def load_blocking():
    groups = []
    path = "data/blocking.csv"
    if not os.path.exists(path): return groups
    with open(path) as f:
        for line in f:
            codes = [c.strip() for c in line.strip().split(',') if c.strip() and c.strip().lower() != 's']
            if len(codes) > 1:
                groups.append(codes)
    return groups

def load_rooms():
    rooms = {}
    id_to_num = {}
    with open(f"{DATA_DIR}/roomsClean.csv", encoding='utf-8-sig') as f:
        for row in csv.reader(f):
            if not row or row[0].strip() in ('','ID'): continue
            try:
                rid = int(row[0].strip())
                department = row[1].strip()
                room_num = row[2].strip()
                rooms[rid] = department
                id_to_num[rid] = room_num
            except ValueError:
                continue
    return rooms, id_to_num

def load_course_names(path="data/CourseNameTable.csv"):
    mapping = {}
    if not os.path.exists(path): return mapping
    with open(path, encoding='utf-8') as f:
        for row in csv.reader(f):
            if len(row) >= 2:
                mapping[row[0].strip()] = row[1].strip()
    return mapping

# ========================== CAPACITIES & ROOMS ==========================
def get_allowed_rooms(course_code, rooms_dict):
    if course_code.startswith(('Y', 'X', 'PBB')): return []
    if course_code.startswith('MWWK'): return [500]
    if course_code.startswith(('MTAUT', 'MTEAD')): return [501]
    if course_code.startswith('MTPOW'): return [502]
    if course_code.startswith('MTROB'): return [503]
    if course_code.startswith('MTDRF'): return [504]
    if course_code.startswith(('MMACS', 'MCMPR')): return [519, 520, 511]
    if course_code.startswith(('MATPH', 'MCH', 'MPH', 'MEVSC')):
        return [525, 528, 529, 533, 534, 535, 536]
    if course_code.startswith(('MDCF', 'MDNC')): return [548]
    if course_code.startswith('MDRM'): return [541]
    if course_code.startswith(('MIMG', 'MIMC', 'MMUC', 'MMUJ', 'MMUO', 'XC')):
        return [514]
    if course_code.startswith(('MPHE', 'MPHED')): return [515, 547]

    general = [r for r, dept in rooms_dict.items()
               if dept in ('Mathematics', 'English', 'Social Studies',
                           'Open', 'Resource', 'Career Centre',
                           'Computer Lab', 'Multi-Purpose room')]
    return general if general else list(rooms_dict.keys())

def course_max_capacity(course_code):
    if any(course_code.startswith(pre) for pre in LAB_COURSE_PREFIXES):
        return LAB_MAX_CAPACITY
    return DEFAULT_MAX_CAPACITY

# ========================== MASTER TIMETABLE ==========================
def build_master_timetable(courses, blocking, rooms_dict, sequencing):
    non_oo = {c: info for c, info in courses.items() if info['type'] != 'OO' and info['sections'] > 0}
    oo_courses = {c: info for c, info in courses.items() if info['type'] == 'OO' and info['sections'] > 0}

    all_sections = []
    for code, info in non_oo.items():
        for i in range(info['sections']):
            all_sections.append((code, i))

    if not all_sections: return {}

    # Union-Find for blocking groups
    parent = {s: s for s in all_sections}
    def find(s):
        while parent[s] != s:
            parent[s] = parent[parent[s]]
            s = parent[s]
        return s
    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb: parent[ra] = rb

    for group in blocking:
        valid = [c for c in group if c in non_oo]
        if len(valid) < 2: continue
        min_sec = min(non_oo[c]['sections'] for c in valid)
        for i in range(min_sec):
            for c in valid[1:]:
                union((valid[0], i), (c, i))

    groups = defaultdict(list)
    for sec in all_sections:
        groups[find(sec)].append(sec)
    groups_list = list(groups.values())

    # Strict Sequencing Requirement Integration
    prereq_courses = set(prereq for prereq, later in sequencing)
    later_courses = set(later for prereq, later in sequencing)

    ed_slots = [(sem, blk, 0) for sem in (1,2) for blk in range(len(BLOCKS))]
    mwf_slots = [(sem, blk, dh) for sem in (1,2) for blk in range(len(BLOCKS)) for dh in (0,1)]
    random.shuffle(ed_slots)   
    random.shuffle(mwf_slots)

    ed_1, ed_2 = [s for s in ed_slots if s[0]==1], [s for s in ed_slots if s[0]==2]
    mwf_1, mwf_2 = [s for s in mwf_slots if s[0]==1], [s for s in mwf_slots if s[0]==2]

    idx_ed_1, idx_ed_2, idx_mwf_1, idx_mwf_2 = 0, 0, 0, 0
    section_slot = {}

    for g_idx, group in enumerate(groups_list):
        has_mwf = any(non_oo[c]['type'] == 'MWF' for c, _ in group)
        
        must_sem1 = any(c in prereq_courses for c, _ in group)
        must_sem2 = any(c in later_courses for c, _ in group)
        
        # Enforce prerequisite to sem 1, later to sem 2
        if must_sem1 and not must_sem2:
            target_sem = 1
        elif must_sem2 and not must_sem1:
            target_sem = 2
        else:
            target_sem = 1 if (g_idx % 2 == 0) else 2

        if has_mwf:
            if target_sem == 1:
                sem, blk, dh = mwf_1[idx_mwf_1 % len(mwf_1)]
                idx_mwf_1 += 1
            else:
                sem, blk, dh = mwf_2[idx_mwf_2 % len(mwf_2)]
                idx_mwf_2 += 1
        else:
            if target_sem == 1:
                sem, blk, dh = ed_1[idx_ed_1 % len(ed_1)]
                idx_ed_1 += 1
            else:
                sem, blk, dh = ed_2[idx_ed_2 % len(ed_2)]
                idx_ed_2 += 1

        for (course, sec_i) in group:
            section_slot[(course, sec_i)] = (sem, blk, dh)

    # Greedy room assignment
    slots = defaultdict(list)
    for (course, sec_i), (sem, blk, dh) in section_slot.items():
        slots[(sem, blk, dh)].append((course, sec_i))

    room_assignment = {}
    for (sem, blk, dh), section_list in slots.items():
        assigned_rooms = set()
        for (course, sec_i) in section_list:
            allowed = get_allowed_rooms(course, rooms_dict) or list(rooms_dict.keys())
            chosen = next((r for r in allowed if r not in assigned_rooms), allowed[0])
            assigned_rooms.add(chosen)
            room_assignment[(course, sec_i)] = chosen

    master = defaultdict(list)
    for (course, sec_i), (sem, blk, dh) in section_slot.items():
        info = non_oo[course]
        room = room_assignment[(course, sec_i)]
        pattern = 'MWF (Day A)' if dh == 0 else 'TT (Day B)' if info['type'] == 'MWF' else 'Every Day'
        master[course].append({
            'section': sec_i + 1, 'semester': sem, 'block': BLOCKS[blk],
            'room': room, 'type': info['type'], 'pattern': pattern
        })

    for code, info in oo_courses.items():
        for i in range(info['sections']):
            master[code].append({
                'section': i+1, 'semester': 1, 'block': 'OO', 'room': 'N/A',
                'type': 'OO', 'pattern': 'Out of Timetable'
            })

    return dict(master)

# ========================== STUDENT ASSIGNMENT ==========================
def assign_students(students, courses, master, sequencing_pairs):
    section_capacity = {
        (course, sec['section']): course_max_capacity(course)
        for course, secs in master.items() for sec in secs
    }
    
    section_counts = defaultdict(int)
    results = []

    for student in sorted(students, key=lambda s: len(s['requests'])):
        reqs = student['requests']
        reqs_set = set(reqs)
        oo_reqs = [r for r in reqs if any(s['type'] == 'OO' for s in master.get(r, []))]
        normal_reqs = sorted([r for r in reqs if r not in oo_reqs], key=lambda r: len(master.get(r, [])))

        # Pre-filter sequencing pairs
        student_prereqs = defaultdict(list)
        student_laters = defaultdict(list)
        for prereq, later in sequencing_pairs:
            if prereq in reqs_set and later in reqs_set:
                student_prereqs[later].append(prereq)
                student_laters[prereq].append(later)

        sorted_course_sections = {
            course: sorted(master.get(course, []), key=lambda s: section_counts[(course, s['section'])])
            for course in normal_reqs
        }

        best_assignment = None   
        best_placed = -1
        course_to_sem = {}

        def dfs(idx, assigned_list, used_slots, placed_courses):
            nonlocal best_assignment, best_placed
            if len(placed_courses) + (len(normal_reqs) - idx) <= best_placed: return
            if idx == len(normal_reqs):
                if len(placed_courses) > best_placed:
                    best_placed = len(placed_courses)
                    best_assignment = assigned_list.copy()
                return
                
            course = normal_reqs[idx]
            for sec in sorted_course_sections.get(course, []):
                sec_num = sec['section']
                if section_counts[(course, sec_num)] >= section_capacity[(course, sec_num)]: continue
                
                sem, blk, pattern = sec['semester'], sec['block'], sec['pattern']
                
                # Handling Linear Courses by mapping specific day-halves
                req_slots = [(sem, blk, 0), (sem, blk, 1)] if pattern == 'Every Day' else \
                            ([(sem, blk, 0)] if 'MWF' in pattern else [(sem, blk, 1)])
                
                if any(rs in used_slots for rs in req_slots): continue
                    
                # Strict Sequencing Enforcement
                valid = True
                for prereq in student_prereqs[course]:
                    if prereq in course_to_sem and course_to_sem[prereq] >= sem:
                        valid = False; break
                if valid:
                    for later in student_laters[course]:
                        if later in course_to_sem and sem >= course_to_sem[later]:
                            valid = False; break
                if not valid: continue
                    
                # Backtracking state changes
                assigned_list.append((course, sec_num, req_slots, pattern))
                for rs in req_slots: used_slots.add(rs)
                placed_courses.append(course)
                
                old_sem = course_to_sem.get(course)
                course_to_sem[course] = sem
                
                dfs(idx+1, assigned_list, used_slots, placed_courses)
                
                # Reverting state
                assigned_list.pop()
                for rs in req_slots: used_slots.remove(rs)
                placed_courses.pop()
                if old_sem is not None: course_to_sem[course] = old_sem
                else: course_to_sem.pop(course, None)
                
            dfs(idx+1, assigned_list, used_slots, placed_courses)

        dfs(0, [], set(), [])

        timetable = []
        placed = []
        if best_assignment:
            for course, sec_num, req_slots, pattern in best_assignment:
                timetable.append({
                    'semester': req_slots[0][0], 'block': req_slots[0][1],
                    'course': course, 'pattern': pattern
                })
                placed.append(course)
                section_counts[(course, sec_num)] += 1
                
        placed.extend(oo_reqs)
        unplaced = [r for r in reqs if r not in placed]

        results.append({
            'id': student['id'], 'grade': student['grade'],
            'requests': reqs, 'timetable': timetable,
            'placed': placed, 'unplaced': unplaced
        })

    return results, section_counts

# ========================== METRICS ==========================
def compute_metrics(student_timetables, section_counts, master, courses, rooms_dict, runtime, sequencing_pairs, blocking_groups):
    # 1. Basic
    total_requests = 0
    total_placed = 0
    students_full = 0
    
    # 2. Section Stats
    total_sections = len(section_counts)
    full_sections = 0
    under_50_sections = 0
    
    for (course, sec_num), count in section_counts.items():
        cap = course_max_capacity(course)
        if count >= cap:
            full_sections += 1
        if count < (cap / 2):
            under_50_sections += 1

    # 1. Student Double-bookings & Linear Violations
    student_double_bookings = 0
    linear_course_violations = 0
    for st in student_timetables:
        seen_slots = set()
        for entry in st['timetable']:
            pat = entry['pattern']
            dhs = [0, 1] if pat == 'Every Day' else ([0] if 'MWF' in pat else [1])
            for dh in dhs:
                slot = (entry['semester'], entry['block'], dh)
                if slot in seen_slots:
                    student_double_bookings += 1
                    if dh in (0, 1): linear_course_violations += 1
                seen_slots.add(slot)

    room_conflicts = 0
    invalid_room_assignments = 0
    room_usage_per_slot = defaultdict(set)
    for course, secs in master.items():
        for sec in secs:
            if sec['room'] == 'N/A' or sec['type'] == 'OO':
                continue
            key = (sec['semester'], sec['block'], sec['room'])
            if course in room_usage_per_slot[key]:
                room_conflicts += 1
            else:
                room_usage_per_slot[key].add(course)
            allowed = get_allowed_rooms(course, rooms_dict)
            if allowed and sec['room'] not in allowed:
                invalid_room_assignments += 1

    # 3. Over Capacity Sections
    over_capacity_sections = 0
    for (course, sec_num), cnt in section_counts.items():
        if cnt > course_max_capacity(course):
            over_capacity_sections += 1

    # 4. Blocking Rule Violations
    blocking_violations = 0
    for group in blocking_groups:
        valid_courses = [c for c in group if c in master]
        if len(valid_courses) < 2: continue
        slots_0 = sorted([(s['semester'], s['block']) for s in master[valid_courses[0]]])
        for c in valid_courses[1:]:
            slots_c = sorted([(s['semester'], s['block']) for s in master[c]])
            if slots_0 != slots_c:
                blocking_violations += 1

    # 5. Sequencing Rule Violations
    sequencing_violations = 0
    for st in student_timetables:
        c_to_s = {entry['course']: entry['semester'] for entry in st['timetable']}
        for prereq, later in sequencing_pairs:
            if prereq in c_to_s and later in c_to_s:
                if c_to_s[prereq] >= c_to_s[later]:
                    sequencing_violations += 1
    students_0_2_unfulfilled = 0
    students_3_8_unfulfilled = 0

    for st in student_timetables:
        n_req = len(st['requests'])
        n_placed = len(st['placed'])
        unplaced_count = len(st['unplaced'])
        
        total_requests += n_req
        total_placed += n_placed
        if n_placed == n_req:
            students_full += 1
            
        if unplaced_count <= 2:
            students_0_2_unfulfilled += 1
        else:
            students_3_8_unfulfilled += 1

    pct_placed = (total_placed / total_requests * 100) if total_requests else 0

    student_conflicts = 0
    student_seq_violations = 0
    for st in student_timetables:
        # Extract the slots from the list of dictionaries
        slots = [(item['semester'], item['block']) for item in st['timetable']]
        seen = set()
        for slot in slots:
            if slot in seen:
                student_conflicts += 1
            else:
                seen.add(slot)
                
        # Map the course to its semester to check for sequencing violations
        placed_sem = {item['course']: item['semester'] for item in st['timetable']}
        
        for pre, post in sequencing_pairs:
            if pre in placed_sem and post in placed_sem:
                if placed_sem[pre] >= placed_sem[post]:
                    student_seq_violations += 1

    master_seq_violations = 0
    for pre, post in sequencing_pairs:
        if pre in master and post in master:
            pre_sems = [s['semester'] for s in master[pre] if s['type'] != 'OO']
            post_sems = [s['semester'] for s in master[post] if s['type'] != 'OO']
            if pre_sems and post_sems:
                # Violation occurs if every possible prerequisite section is at the same time or after the post-requisites
                if min(pre_sems) >= max(post_sems):
                    master_seq_violations += 1

    room_conflicts = 0
    invalid_room_assignments = 0
    room_usage_per_slot = defaultdict(set)
    for course, secs in master.items():
        for sec in secs:
            if sec['room'] == 'N/A' or sec['type'] == 'OO':
                continue
            key = (sec['semester'], sec['block'], sec['room'])
            if course in room_usage_per_slot[key]:
                room_conflicts += 1
            else:
                room_usage_per_slot[key].add(course)
            allowed = get_allowed_rooms(course, rooms_dict)
            if allowed and sec['room'] not in allowed:
                invalid_room_assignments += 1

    overfilled = 0
    for (course, sec_num), cnt in section_counts.items():
        cap = course_max_capacity(course)
        if cnt > cap:
            overfilled += 1

    block_counts = defaultdict(int)
    for course, secs in master.items():
        for sec in secs:
            if sec['type'] != 'OO':
                block_counts[(sec['semester'], sec['block'])] += 1
                
    if block_counts:
        avg = sum(block_counts.values()) / len(block_counts)
        balanced_sections = sum(1 for cnt in block_counts.values() if abs(cnt - avg) <= 1)
        max_dev = max(max(block_counts.values()) - avg, avg - min(block_counts.values()))
    else:
        balanced_sections = 0
        max_dev = 0

    

    n_students = len(student_timetables)
    pct_full = (students_full / n_students * 100) if n_students else 0
    students_7plus = sum(1 for st in student_timetables if len(st['placed']) >= 7)
    pct_7plus = (students_7plus / n_students * 100) if n_students else 0
    pct_0_2 = (students_0_2_unfulfilled / n_students * 100) if n_students else 0
    pct_3_8 = (students_3_8_unfulfilled / n_students * 100) if n_students else 0

    score = max(0, (total_placed * 10) + (students_full * 50) - (room_conflicts * 1000) - 
                    (student_conflicts * 1000) - (invalid_room_assignments * 500) - 
                    (overfilled * 1000) + balanced_sections)

    return {
        'total_requests': total_requests,
        'total_placed': total_placed,
        'number_of_students': n_students,
        'pct_requests_placed': round(pct_placed, 2),
        'students_full_8_of_8': students_full,
        'pct_full_8_of_8': round(pct_full, 2),
        'students_7_plus': students_7plus,
        'pct_7_plus': round(pct_7plus, 2),
        'students_0_2_unfulfilled': students_0_2_unfulfilled,
        'pct_0_2_unfulfilled': round(pct_0_2, 2),
        'students_3_8_unfulfilled': students_3_8_unfulfilled,
        'pct_3_8_unfulfilled': round(pct_3_8, 2),
        'master_seq_violations': master_seq_violations,
        'student_seq_violations': student_seq_violations,
        'student_conflicts': student_conflicts,
        'unassigned_requests': total_requests - total_placed,
        'total_sections': len(section_counts),
        'room_conflicts': room_conflicts,
        'invalid_room_assignments': invalid_room_assignments,
        'overfilled_classes': overfilled,
        'balanced_sections': balanced_sections,
        'block_distribution': dict(block_counts),
        'optimization_score': score,
        'runtime_seconds': runtime / 1000000000,
        'total_sections': total_sections,
        'full_sections': full_sections,
        'sections_under_half': under_50_sections,

        #score
        'SCtotal_placed': total_placed,
        'SCstudents_full': students_full,
        'SCroom_conflicts': room_conflicts,
        'SCstudent_conflicts': student_conflicts,
        'SCinvalid_room_assignments': invalid_room_assignments,
        'SCoverfilled': overfilled,
        'SCbalanced_sections': balanced_sections,

        'WSCstudents_full': students_full,
        'SCroom_conflicts': room_conflicts,
        'SCstudent_conflicts': student_conflicts,
        'SCinvalid_room_assignments': invalid_room_assignments,
        'SCoverfilled': overfilled,
        'SCbalanced_sections': balanced_sections,

        # Hard Constraint Metrics added for output:
        'student_double_bookings': student_double_bookings,
        'room_double_bookings': room_conflicts,
        'over_capacity_sections': over_capacity_sections,
        'invalid_room_assignments': invalid_room_assignments,
        'blocking_violations': blocking_violations,
        'sequencing_violations': sequencing_violations,
        'linear_course_violations': linear_course_violations,
    }

def print_metrics(m, old=None):
    W = 76
    def row(lbl, val, w=46):
        print(f"  {lbl:<{w}} {val}")

    print("=" * W)
    print("  MILESTONE 4 METRICS REPORT")
    print("=" * W)

    print("\n── STUDENT PLACEMENT ────────────────────────────────────────────────")
    row("Total requests:",              m['total_requests'])
    row("Total requests placed:",              m['total_placed'])
    row("% requests placed:",                 f"{m['pct_requests_placed']}%")
    row("Students with 8/8 requested:",        f"{m['students_full_8_of_8']}  ({m['pct_full_8_of_8']}%)")
    row("Students with 7–8/8 requested:",      f"{m['students_7_plus']}  ({m['pct_7_plus']}%)")
    row("Students with timetable conflicts:",  m['student_conflicts'])
    row("Unassigned course requests:",         m['unassigned_requests'])
    row("Students w/ 0-2 unfulfilled courses:",    f"{m['students_0_2_unfulfilled']}  ({m['pct_0_2_unfulfilled']}%)")
    row("Students w/ 3-8 unfulfilled courses:",    f"{m['students_3_8_unfulfilled']}  ({m['pct_3_8_unfulfilled']}%)")

    print("\n── TIMETABLE QUALITY ────────────────────────────────────────────────")
    row("Generation runtime:",                 f"{m['runtime_seconds']:.2f} sec")
    row("Balanced blocks (±2 of avg):",        m['balanced_sections'])
    row("Optimization score:",                 m['optimization_score'])

    print()
    print("HARD CONSTRAINTS VIOLATIONS:")
    print("-" * 30)
    print(f"  Student double-bookings:            {m['student_double_bookings']}")
    print(f"  Room double-bookings:               {m['room_double_bookings']}")
    print(f"  Over-capacity sections:             {m['over_capacity_sections']}")
    print(f"  Invalid room assignments:           {m['invalid_room_assignments']}")
    print(f"  Blocking rule violations:           {m['blocking_violations']}")
    print(f"  Sequencing rule violations:         {m['sequencing_violations']}")
    print(f"  Linear course violations:           {m['linear_course_violations']}\n")

    print("\n── SCORE BREAKDOWN ────────────────────────────────────────────────")
    row("Total requests placed: +", m['SCtotal_placed'] * 10)
    row("Students full: +",              m['SCstudents_full'] * 50)
    row("Room Conflicts: -",    m['SCroom_conflicts'] * 1000)
    row("Student Conflicts: -",        m['SCstudent_conflicts'] * 1000)
    row("Invalid Room Assignment: -", m['SCinvalid_room_assignments'] * 500)
    row("Overfilled: -",  m['SCoverfilled'] * 1000)
    row("Balanced Sections: -", m['SCbalanced_sections'])
    #row("Optimization score:",                 m['optimization_score'])


    print("\n── BLOCK DISTRIBUTION ───────────────────────────────────────────────")
    print(f"  {'Slot':<16} {'Sections':>8}  Bar")
    for (sem, blk), cnt in sorted(m['block_distribution'].items()):
        bar = '█' * (cnt // 3)
        print(f"  Sem{sem} Block {blk}     {cnt:>5}  {bar}")

def export_student_csv(master, sts, course_names, id_to_num, fname='student_timetables.csv'):
    rows = []
    for st in sts:
        # Iterate over the list of dictionaries
        for entry in st['timetable']:
            sem = entry['semester']
            blk = entry['block']
            course = entry['course']
            room = 'N/A'
            
            for sec in master.get(course, []):
                if sec['semester'] == sem and sec['block'] == blk:
                    if sec['room'] is not None:
                        room = id_to_num.get(sec['room'], 'N/A')
                    break
                    
            status = ('requested' if course in st['requests'] else 'alternate')
            rows.append({'StudentID': st['id'], 'Grade': st['grade'],
                         'Semester': sem, 'Block': blk,
                         'Course': course_names.get(course, course),
                         'Room': room, 'Status': status})
                         
        # Unplaced logic remains the same
        for course in st['unplaced']:
            rows.append({'StudentID': st['id'], 'Grade': st['grade'],
                         'Semester': 'UA', 'Block': 'UA',
                         'Course': course_names.get(course, course),
                         'Room': '', 'Status': 'unplaced'})

def export_master_csv_crosstab(master, sec_counts, course_names, id_to_num, fname='master_timetable.csv'):
    blocks_order = ['A', 'B', 'C', 'D']
    sems = [1, 2]
    slot_lists = {(sem, blk): [] for sem in sems for blk in blocks_order}
    for course, secs in master.items():
        for sec in secs:
            if sec['block'] == 'OO' or sec['type'] == 'OO':
                continue
            room_display = (id_to_num.get(sec['room'], 'N/A') if sec['room'] is not None else 'N/A')
            enrolled = sec_counts.get((course, sec['section']), 0)
            slot_lists[(sec['semester'], sec['block'])].append({
                'Course':   course_names.get(course, course),
                'Section':  sec['section'],
                'Room':     room_display,
                'Enrolled': enrolled,
            })
    max_rows = max((len(v) for v in slot_lists.values()), default=0)
    header1  = [f"Sem {sem} Block {blk}" if j == 0 else "" for sem in sems for blk in blocks_order for j in range(4)]
    header2  = ["Course", "Sec", "Room", "Enrolled"] * (len(sems) * len(blocks_order))
    data_rows = []
    for i in range(max_rows):
        row = []
        for sem in sems:
            for blk in blocks_order:
                lst = slot_lists[(sem, blk)]
                if i < len(lst):
                    item = lst[i]
                    row.extend([item['Course'], item['Section'], item['Room'], item['Enrolled']])
                else:
                    row.extend(["", "", "", ""])
        data_rows.append(row)
    with open(fname, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(header1)
        writer.writerow(header2)
        writer.writerows(data_rows)

# ========================== MAIN ==========================
def main():
    print("\n" + "=" * 70)
    print("  SCHOOL TIMETABLING — MILESTONE 4")
    print("=" * 70 + "\n")

    print("Loading data...")
    courses = load_courses()
    students = load_students()
    sequencing = load_sequencing()
    blocking = load_blocking()
    rooms, id_to_num = load_rooms()
    course_names = load_course_names()

    print(f"  Courses: {len(courses)} | Students: {len(students)} | "
          f"Sequencing rules: {len(sequencing)} | Blocking groups: {len(blocking)}\n")

    print("Building master timetable with smart greedy logic...")
    start = perf_counter_ns()
    master = build_master_timetable(courses, blocking, rooms, sequencing)
    timetaken = perf_counter_ns() - start
    
    if master is None:
        print("ERROR: No feasible master timetable found.")
        return

    total_sections = sum(len(v) for v in master.values())
    print(f"  ✓ Master timetable built: {len(master)} courses, {total_sections} sections\n")

    print("Assigning students to sections with sequencing and capacities...")
    start = perf_counter_ns()
    student_timetables, section_counts = assign_students(students, courses, master, sequencing)
    timetaken += perf_counter_ns() - start
    print(f"  ✓ {len(student_timetables)} students assigned\n")

    metrics = compute_metrics(student_timetables, section_counts, master, courses, rooms, timetaken, sequencing, blocking)
    print_metrics(metrics)

    print("\nExporting CSV files...")
    export_master_csv_crosstab(master, section_counts, course_names, id_to_num, 'master_timetable.csv')
    export_student_csv(master, student_timetables, course_names, id_to_num, 'student_timetables.csv')
    print("Done.")

if __name__ == '__main__':
    main()