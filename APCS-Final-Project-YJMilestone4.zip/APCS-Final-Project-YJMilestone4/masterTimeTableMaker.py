import csv
import os
from ortools.sat.python import cp_model

def create_dummy_csv_files():
    """Populates mock data if files are missing."""
    if not os.path.exists('sections.csv'):
        with open('sections.csv', 'w', newline='') as f:
            writer = csv.writer(f)
            # Added a 5th column for alternative room types
            writer.writerow(['course_code', 'num_sections', 'schedule_type', 'room_type', 'alt_room_type'])
            writer.writerows([
                ['FOOD11', '2', 'MWF', 'Kitchen', 'Classroom'],  # Can use Kitchen OR Classroom
                ['FOOD12', '2', 'MWF', 'Kitchen', ''],           # Strictly Kitchen
                ['MATH101', '1', 'ED', 'Classroom', 'Lab'],      # Can use Classroom OR Lab
                ['MATH102', '1', 'ED', 'Classroom', ''],
                ['PHY101', '1', 'MWF', 'Lab', ''],
                ['CHEM101', '1', 'OO', 'Classroom', '']
            ])
    if not os.path.exists('sequence.csv'):
        with open('sequence.csv', 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerows([
                ['MATH101', 'MATH102']
            ])
    if not os.path.exists('blocking.csv'):
        with open('blocking.csv', 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['FOOD11,FOOD12,s'])
            
    if not os.path.exists('roomsClean.csv'):
        with open('roomsClean.csv', 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['room_number', 'room_type'])
            writer.writerows([
                ['500', 'Kitchen'],
                ['501', 'Kitchen'],
                ['502', 'Classroom'],
                ['503', 'Classroom'],
                ['504', 'Lab'],
                ['505', 'Lab']
            ])

def load_data():
    # 1. Load sections, schedule types, primary room types, and alternative room types
    sections = {}
    course_types = {}
    course_room_types = {}
    course_alt_room_types = {}
    
    with open('sections.csv', mode='r') as f:
        reader = csv.reader(f)
        next(reader, None)  # Skip header
        for row in reader:
            if not row: continue
            course = row[0].strip()
            num = int(row[1].strip())
            sched_type = row[2].strip().upper() if len(row) > 2 and row[2].strip() else 'ED'
            room_type = row[3].strip() if len(row) > 3 and row[3].strip() else 'Classroom'
            alt_room_type = row[4].strip() if len(row) > 4 and row[4].strip() else ''
            
            sections[course] = num
            course_types[course] = sched_type
            course_room_types[course] = room_type
            course_alt_room_types[course] = alt_room_type

    # 2. Load sequencing
    sequencing = []
    if os.path.exists('sequence.csv'):
        with open('sequence.csv', mode='r') as f:
            reader = csv.reader(f)
            for row in reader:
                if not row or len(row) < 2: continue
                sequencing.append((row[0].strip(), row[1].strip()))

    # 3. Load blocking
    blocking = []
    if os.path.exists('blocking.csv'):
        with open('blocking.csv', mode='r') as f:
            reader = csv.reader(f)
            for row in reader:
                if not row: continue
                courses = []
                for cell in row:
                    for part in cell.split(','):
                        c_clean = part.strip()
                        if c_clean and c_clean.lower() not in ['s', 'n', 'c']:
                            courses.append(c_clean)
                if len(courses) > 1:
                    blocking.append(courses)
                    
    # 4. Load rooms mapping from roomsClean.csv
    rooms_by_type = {}
    all_rooms = []
    if os.path.exists('roomsClean.csv'):
        with open('roomsClean.csv', mode='r') as f:
            reader = csv.reader(f)
            next(reader, None)
            for row in reader:
                if not row: continue
                try:
                    r_num = int(row[0].strip())
                    r_type = row[1].strip()
                    all_rooms.append(r_num)
                    if r_type not in rooms_by_type:
                        rooms_by_type[r_type] = []
                    rooms_by_type[r_type].append(r_num)
                except ValueError:
                    continue
                    
    if not all_rooms:
        all_rooms = list(range(500, 549))
        rooms_by_type = {'Classroom': all_rooms}
                    
    return sections, sequencing, blocking, course_types, course_room_types, course_alt_room_types, rooms_by_type, all_rooms

def generate_timetable():
    sections, sequencing, blocking, course_types, course_room_types, course_alt_room_types, rooms_by_type, all_rooms = load_data()

    # --- Pre-process Blocking Groups to Treat Them as One Single Course ---
    while True:
        changes_made = False
        for block_group in blocking:
            valid_courses = [c for c in block_group if c in sections]
            if not valid_courses: continue
            
            max_sections = max(sections[c] for c in valid_courses)
            
            types_in_group = {course_types[c] for c in valid_courses if c in course_types}
            if 'ED' in types_in_group:
                group_type = 'ED'
            elif 'MWF' in types_in_group:
                group_type = 'MWF'
            elif 'OO' in types_in_group:
                group_type = 'OO'
            else:
                group_type = 'ED'
                
            room_types_in_group = [course_room_types[c] for c in valid_courses if c in course_room_types]
            group_room_type = room_types_in_group[0] if room_types_in_group else 'Classroom'
            
            alt_room_types_in_group = [course_alt_room_types[c] for c in valid_courses if c in course_alt_room_types]
            group_alt_room_type = alt_room_types_in_group[0] if alt_room_types_in_group else ''
            
            for c in block_group:
                if (sections.get(c) != max_sections or 
                    course_types.get(c) != group_type or 
                    course_room_types.get(c) != group_room_type or
                    course_alt_room_types.get(c) != group_alt_room_type):
                    
                    sections[c] = max_sections
                    course_types[c] = group_type
                    course_room_types[c] = group_room_type
                    course_alt_room_types[c] = group_alt_room_type
                    changes_made = True
                    
        if not changes_made:
            break

    all_sections = []
    for course, num in sections.items():
        for i in range(num):
            all_sections.append((course, i))

    # --- Union-Find for Blocked Courses ---
    parent = {sec: sec for sec in all_sections}

    def find(sec):
        if parent[sec] == sec:
            return sec
        parent[sec] = find(parent[sec])
        return parent[sec]

    def union(sec1, sec2):
        root1 = find(sec1)
        root2 = find(sec2)
        if root1 != root2:
            parent[root1] = root2

    for block_group in blocking:
        valid_courses = [c for c in block_group if c in sections]
        if len(valid_courses) < 2: continue
        
        max_sections = max(sections[c] for c in valid_courses)
        for i in range(max_sections):
            first_sec = (valid_courses[0], i)
            for alternate_course in valid_courses[1:]:
                union(first_sec, (alternate_course, i))

    sessions_dict = {}
    for sec in all_sections:
        root = find(sec)
        if root not in sessions_dict:
            sessions_dict[root] = []
        sessions_dict[root].append(sec)

    sessions = list(sessions_dict.values())

    # Resolve schedule type, room type, and alternative room type per composite session group
    session_types = []
    session_room_types = []
    session_alt_room_types = []
    
    for session_sections in sessions:
        types_in_session = {course_types[course] for course, _ in session_sections}
        if 'ED' in types_in_session:
            s_type = 'ED'
        elif 'MWF' in types_in_session:
            s_type = 'MWF'
        elif 'OO' in types_in_session:
            s_type = 'OO'
        else:
            s_type = 'ED'
        session_types.append(s_type)
        
        room_types_in_session = {course_room_types[course] for course, _ in session_sections if course in course_room_types}
        s_room_type = list(room_types_in_session)[0] if room_types_in_session else 'Classroom'
        session_room_types.append(s_room_type)
        
        alt_room_types_in_session = {course_alt_room_types[course] for course, _ in session_sections if course in course_alt_room_types}
        s_alt_room_type = list(alt_room_types_in_session)[0] if alt_room_types_in_session else ''
        session_alt_room_types.append(s_alt_room_type)

    # --- BOTTLENECK CHECK ---
    is_impossible = check_room_capacities(sessions, session_types, session_room_types, session_alt_room_types, rooms_by_type)
    if is_impossible:
        print("Stopping early: Schedule is mathematically impossible based on room capacity.")
        return

    # --- CP-SAT Solver Setup ---
    model = cp_model.CpModel()
    BLOCKS = ['a', 'b', 'c', 'd']

    sem_vars = []
    block_vars = []
    room_vars = []
    day_half_vars = {}
    global_slot_vars = []

    for idx in range(len(sessions)):
        s_type = session_types[idx]
        s_room_type = session_room_types[idx]
        s_alt_room_type = session_alt_room_types[idx]
        
        sem = model.NewIntVar(1, 2, f'sem_{idx}')
        sem_vars.append(sem)
        
        if s_type == 'OO':
            block = model.NewIntVar(0, 0, f'block_{idx}')
            room = model.NewIntVar(0, 0, f'room_{idx}')
            block_vars.append(block)
            room_vars.append(room)
            day_half_vars[idx] = None
        else:
            block = model.NewIntVar(0, len(BLOCKS) - 1, f'block_{idx}')
            
            # Combine primary and alternative rooms into a single pool of allowed room values
            primary_rooms = rooms_by_type.get(s_room_type, [])
            alt_rooms = rooms_by_type.get(s_alt_room_type, []) if s_alt_room_type else []
            allowed_rooms = list(set(primary_rooms + alt_rooms))
            
            if not allowed_rooms:
                allowed_rooms = all_rooms if all_rooms else [500]
                
            # CP-SAT Domain constraint cleanly allows either primary OR alternative room indices
            room_domain = cp_model.Domain.FromValues(allowed_rooms)
            room = model.NewIntVarFromDomain(room_domain, f'room_{idx}')
            
            block_vars.append(block)
            room_vars.append(room)
            
            if s_type == 'ED':
                day_half_vars[idx] = None
                global_slot_0 = model.NewIntVar(0, 200000, f'global_slot_{idx}_d0')
                global_slot_1 = model.NewIntVar(0, 200000, f'global_slot_{idx}_d1')
                model.Add(global_slot_0 == room + 1000 * block + 10000 * sem + 100000 * 0)
                model.Add(global_slot_1 == room + 1000 * block + 10000 * sem + 100000 * 1)
                global_slot_vars.append(global_slot_0)
                global_slot_vars.append(global_slot_1)
                
            elif s_type == 'MWF':
                day_half = model.NewIntVar(0, 1, f'day_half_{idx}')
                day_half_vars[idx] = day_half
                
                global_slot = model.NewIntVar(0, 200000, f'global_slot_{idx}')
                model.Add(global_slot == room + 1000 * block + 10000 * sem + 100000 * day_half)
                global_slot_vars.append(global_slot)

    if global_slot_vars:
        model.AddAllDifferent(global_slot_vars)

    # --- Sequencing Constraint ---
    sec_to_session_idx = {}
    for idx, session_sections in enumerate(sessions):
        for sec in session_sections:
            sec_to_session_idx[sec] = idx

    for course_pre, course_post in sequencing:
        if course_pre in sections and course_post in sections:
            for s_pre in range(sections[course_pre]):
                for s_post in range(sections[course_post]):
                    idx_pre = sec_to_session_idx[(course_pre, s_pre)]
                    idx_post = sec_to_session_idx[(course_post, s_post)]
                    model.Add(sem_vars[idx_pre] < sem_vars[idx_post])

    # --- Semester Balancing Objective ---
    sem1_vars = []
    weights = []
    for idx, session_sections in enumerate(sessions):
        sem1_var = model.NewBoolVar(f'sem1_{idx}')
        model.Add(sem_vars[idx] == 1).OnlyEnforceIf(sem1_var)
        model.Add(sem_vars[idx] == 2).OnlyEnforceIf(sem1_var.Not())
        sem1_vars.append(sem1_var)
        weights.append(len(session_sections))
        
    total_sections = sum(weights)
    target = total_sections // 2
    
    sem1_sum = model.NewIntVar(0, total_sections, 'sem1_sum')
    model.Add(sem1_sum == sum(sem1_vars[i] * weights[i] for i in range(len(sem1_vars))))
    
    diff = model.NewIntVar(-total_sections, total_sections, 'diff')
    model.Add(diff == sem1_sum - target)
    
    abs_diff = model.NewIntVar(0, total_sections, 'abs_diff')
    model.AddAbsEquality(abs_diff, diff)
    
    model.Minimize(abs_diff)

    # --- Solve ---
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = 60.0
    status = solver.Solve(model)

    if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        output_rows = []
        for idx, session_sections in enumerate(sessions):
            s_type = session_types[idx]
            s_sem = solver.Value(sem_vars[idx])
            
            if s_type == 'OO':
                s_block = 'OO'
                s_room = 'N/A'
                s_pattern = 'Out of TT'
            else:
                s_block = BLOCKS[solver.Value(block_vars[idx])].upper()
                s_room = solver.Value(room_vars[idx])
                if s_type == 'ED':
                    s_pattern = 'Every Day'
                elif s_type == 'MWF':
                    dh = solver.Value(day_half_vars[idx])
                    s_pattern = 'MWF (Day A)' if dh == 0 else 'TT (Day B)'
            
            for course, sec_num in session_sections:
                output_rows.append({
                    'Semester': s_sem,
                    'Block': s_block,
                    'Room': s_room,
                    'Course Code': course,
                    'Section': sec_num + 1,
                    'Type': s_type,
                    'Pattern': s_pattern
                })
        
        output_rows.sort(key=lambda x: (
            x['Semester'], 
            x['Block'], 
            999 if x['Room'] == 'N/A' else x['Room'], 
            x['Course Code'],
            x['Section']
        ))
        
        # --- EXPORT FORMAT FOR CSV ---
        output_filename = 'timetable_output.csv'
        with open(output_filename, mode='w', newline='') as f:
            writer = csv.writer(f)
            
            blocks_list = [b.upper() for b in BLOCKS]
            if any(row['Block'] == 'OO' for row in output_rows):
                blocks_list.append('OO')
            
            num_cols_per_sem = len(blocks_list)
            
            writer.writerow(["Master Timetable"] + [""] * (2 * num_cols_per_sem - 1))
            writer.writerow(["Semester 1"] + [""] * (num_cols_per_sem - 1) + ["Semester 2"] + [""] * (num_cols_per_sem - 1))
            writer.writerow([f"Block {b}" if b != 'OO' else "OO" for b in blocks_list] * 2)
            
            columns_data = {(sem, block): [] for sem in [1, 2] for block in blocks_list}
            for row in output_rows:
                sem = row['Semester']
                block = row['Block']
                entry = f"{row['Course Code']} (Sec {row['Section']})"
                if (sem, block) in columns_data:
                    columns_data[(sem, block)].append(entry)
            
            max_rows = max(len(columns_data[(sem, block)]) for sem in [1, 2] for block in blocks_list) if columns_data else 0
            
            for i in range(max_rows):
                current_row = []
                for sem in [1, 2]:
                    for block in blocks_list:
                        if i < len(columns_data[(sem, block)]):
                            current_row.append(columns_data[(sem, block)][i])
                        else:
                            current_row.append("")
                writer.writerow(current_row)
            
        print(f"Results successfully saved to '{output_filename}'\n")

        print(f"{'Sem':<5} | {'Block':<6} | {'Room':<5} | {'Course':<10} | {'Section':<7} | {'Type':<5} | {'Pattern'}")
        print("-" * 65)
        for row in output_rows:
            print(f"{row['Semester']:<5} | {row['Block']:<6} | {row['Room']:<5} | {row['Course Code']:<10} | {row['Section']:<7} | {row['Type']:<5} | {row['Pattern']}")
    else:
        print("Failed: No valid schedule configuration found satisfying all parameters.")

def check_room_capacities(sessions, session_types, session_room_types, session_alt_room_types, rooms_by_type):
    print("\n==================================================")
    print("           ROOM CAPACITY BOTTLENECK REPORT        ")
    print("==================================================")
    
    demand_by_type = {}
    strict_demand_by_type = {}
    
    # Calculate demand requirements
    for idx, r_type in enumerate(session_room_types):
        s_type = session_types[idx]
        alt_type = session_alt_room_types[idx]
        if s_type == 'OO':
            continue
            
        slots_needed = 2 if s_type == 'ED' else 1
        
        # Primary room type tracking
        demand_by_type[r_type] = demand_by_type.get(r_type, 0) + slots_needed
        
        # Track strict demand (courses that have no alternative room)
        if not alt_type or alt_type == r_type:
            strict_demand_by_type[r_type] = strict_demand_by_type.get(r_type, 0) + slots_needed
        
    has_critical_failure = False
    all_room_types = set(list(rooms_by_type.keys()) + list(demand_by_type.keys()))
    
    for r_type in sorted(all_room_types):
        rooms = rooms_by_type.get(r_type, [])
        num_rooms = len(rooms)
        
        total_supply = num_rooms * 16 
        demand = demand_by_type.get(r_type, 0)
        strict_demand = strict_demand_by_type.get(r_type, 0)
        
        utilization = (demand / total_supply) * 100 if total_supply > 0 else 0
        
        print(f"Room Type: [ {r_type} ]")
        print(f"  - Physical Rooms Available: {num_rooms} (Total capacity: {total_supply} half-slots)")
        print(f"  - Primary Requested Demand: {demand} half-slots (Strict/Unmovable: {strict_demand})")
        
        if num_rooms == 0 and strict_demand > 0:
            print(f"  ❌ CRITICAL ERROR: Courses strictly require '{r_type}' rooms, but 0 exist in roomsClean.csv!")
            has_critical_failure = True
        elif strict_demand > total_supply:
            print(f"  ❌ CRITICAL BOTTLENECK: Strict unmovable demand ({strict_demand}) exceeds capacity ({total_supply})!")
            has_critical_failure = True
        elif demand > total_supply:
            print(f"  ⚠️ POTENTIAL OVERFLOW: Primary demand exceeds capacity, but alternative rooms may alleviate this.")
        elif utilization > 87.5:
            print(f"  ⚠️ HIGH RISK ({utilization:.1f}%): Tight packing may trigger solver failure under strict rules.")
        else:
            print(f"  ✅ OK ({utilization:.1f}% primary utilization)")
        print("-" * 50)
        
    print("==================================================\n")
    return has_critical_failure

if __name__ == '__main__':
    create_dummy_csv_files()
    generate_timetable()
